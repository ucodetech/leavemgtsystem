<?php
  $db = mysqli_connect('127.0.0.1', 'uzbgraph_graveth', 'echo@mike12@@@', 'uzbgraph_LMS_DB');
  session_start();
  if (mysqli_connect_errno()) {
    echo 'Database connection failed with errors: '  .mysqli_connect_error();
    die();
  }

    


//Super admin session
 if (isset($_SESSION['SUPERadmin'])) {
      $super_admin_id = $_SESSION['SUPERadmin'];
      $querysuper = $db->query("SELECT * FROM superuser WHERE super_id = '$super_admin_id'");
      $super_data = mysqli_fetch_assoc($querysuper);
      $fn = explode(' ', $super_data['super_full_name']);
      $super_data['first'] = $fn[0];
      $super_data['last'] = $fn[1];
    }

//Student session
if (isset($_SESSION['LMSuser'])) {
      $student_session_id = $_SESSION['LMSuser'];
      $querystud = $db->query("SELECT * FROM students WHERE student_id = '$student_session_id'");
      $user_data = mysqli_fetch_assoc($querystud);
      $fnd = explode(' ', $user_data['student_full_name']);
      $user_data['first'] = $fnd[0];
      $user_data['last'] = $fnd[1];




    }
    //librarian session
if (isset($_SESSION['LIBser'])) {
      	$librarian_id = $_SESSION['LIBser'];
      	$querylib = $db->query("SELECT * FROM `librarian` WHERE lib_id = '$librarian_id'");
      	$librarian_data = mysqli_fetch_assoc($querylib);
      	$fnl = explode(' ', $librarian_data['lib_full_name']);
      	$librarian_data['first'] = $fnl[0];

      }
    

  if(isset($_SESSION['success_flash'])){
    echo '<div class="bg-success"><p class="text-light text-center">'.$_SESSION['success_flash'].'<br></p></div>';
    	unset($_SESSION['success_flash']);
    }


  if(isset($_SESSION['error_flash'])){
    echo '<div class="bg-danger"><p class="text-light text-center">'.$_SESSION['error_flash'].'</p></div>';
    	unset($_SESSION['error_flash']);
    }
