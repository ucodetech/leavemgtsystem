<?php

 require_once '../core/init.php';
require_once '../helpers/helpers.php';
		 
	if($_POST['action']){
	   if($_POST['action'] == "update_time"){
	       
	   $sql = "UPDATE students SET student_last_login = now()  WHERE student_id = '$student_session_id'";
	   $query = $db->query($sql);
	  
	  
	       
	   }
	 
	 
	   
	   
	}	 
		
