<?php
require_once '../core/init.php';
 require_once '../helpers/helpers.php';   
 include 'includes/head.php';

?>
   <style type="text/css">
   	label{
   		color: #fff !important;
   		font-family:Poppins !important;
   		font-weight: bolder;
   	}
   	.card-header{
   		font-size: 20px !important;
   		font-family:Poppins !important;
   	}
   </style>
            <div class="content">
                <div class="container">
	<div class="jumbotron text-center" style="margin-bottom: 0; padding: 1rem 1rem;">
    <img src="../images/hg.png" class="img-fluid" width="300" alt="LMS Logo">
		
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				
			</div>
			<div class="col-md-6" style="margin-top: 20px;">
				<div class="card bg-dark">
					<div class="card-header text-center">
						<i class="fa fa-user"></i>RESET PASSWORD
					</div>
					<div class="card-body">
		                
					  <?php 
            $selector = $_GET['selector'];
            $validator = $_GET['validator'];
            
            if(empty($selector || empty($validator))){
                echo "Could not validate your request!";
            }else{
              if (ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false) {
                ?>
                <form method="post"  action="includes/reset-password.php">
                  <div class="form-group">
                    <input type="hidden" name="selector" value="<?=$selector;?>">
                    <input type="hidden" name="validator" value="<?=$validator;?>">
                    <label>Enter Password</label>
                  <input type="password" name="student_password" id="student_password" class="form-control">
                  </div>
                  <div class="form-group">
                    <label>Confirm Password</label>
                  <input type="password" name="student_confirm_password" id="student_confirm_password" class="form-control">
                  </div>
                  <div class="form-group">
                  <input type="submit" name="ResetPassword" id="ResetPassword" value="Reset Password" class="btn btn-info">
                  
                </div>
          </form>
                <?php
              }
            }

    						 ?>


				
					</div>
				</div>
				
			</div>
			
		</div>

	</div>


                </div>
            </div>
<?php include 'includes/footer1.php'; ?>
<script type="text/javascript">

</script>