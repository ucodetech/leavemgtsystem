<?php
require_once '../core/init.php';
require_once '../helpers/helpers.php';
		 
  if (!is_logged_in()) {
  	login_error_redirect();
  }

  if (!has_permission_student('studentApproved')) {
  	student_permission_error_redirect();
  }
    include 'includes/head.php';
    include 'includes/nav.php';

?>
   
  <?php 
      $sql = "SELECT * FROM `book_categories` WHERE book_parent = 0 ";
      $pquery = $db->query($sql);
      $count = mysqli_num_rows($pquery );

      $sqlcount = "SELECT * FROM `books` WHERE book_deleted = 0 ";
      $pcount = $db->query($sqlcount);
        $count = mysqli_num_rows($pcount);

    $sqlm = "SELECT * FROM messages WHERE student = '$student_session_id' AND hasRead = 0 ";
    $querym = $db->query($sqlm);
    $read = mysqli_num_rows($querym);
    $readget = mysqli_fetch_assoc($querym);

   ?>
  <meta http-equiv="refresh" content="60">
    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <?php include 'filters.php'; ?>
      </div><!-- /.container-fluid -->
       <?php if (isset($readget)): ?>
         <div class="alert alert-success alert-dismissable fade show" id="student-success">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>
        New Message Please read 
        <span class="badge badge-danger">
          <?=$read;?> 
        </span>
      </strong> 
      <a href="notifications.php">Read</a> 
    </div>
       <?php endif ?>
    </div>
   
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <h2 class="text-center text-info">All books By Category</h2><hr>
            <div class="row">
               
          <?php while ($parent = mysqli_fetch_assoc($pquery)): ?>
            <?php 
            $parent_id = $parent['cat_id'];
            $sql2 = "SELECT * FROM `book_categories` WHERE book_parent = '$parent_id' ";
            $cquery = $db->query($sql2)
             ?>
           <div class="col-md-3">
            <div class="dropdown">
              <span><?=$parent['category'];?></span> <br>
              <i class="dropdown-toggle fa fa-folder-open fo" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
  
            <div class="dropdown-menu" style="background-color: none;" aria-labelledby="dropdownMenuButton">
              <?php while($child = mysqli_fetch_assoc($cquery)): ?>
              <a class="dropdown-item" href="categories.php?cat=<?=$child['cat_id'];?> "><i class="fa fa-file"></i><br><span class="na"><?=$child['category'];?></span></a>
             <?php endwhile; ?>
             
            
            </div>
          </div>
        </div>
             <?php endwhile; ?>
              </div>
          
               

    </div><!-- /.container-fluid -->
    
  </div><!-- /.content -->
 

 
  
</div> <!-- /.content-wrapper -->
           
           
           
<?php include 'includes/footer.php';?>
<script>
     $('document').ready(function(){
    	        update_student_login();
    	       
    			function update_student_login()
    			{
    			    var action = 'update_time';
    			    $.ajax({
    			       url:"action.php",
    			       method:"POST",
    			       data:{action:action},
    			       success:function(data)
    			       {
    			        
    			         
    			       },
    			       error:function(){alert("something went wrong")}
    			      
    			    });
    			}
    			 setInterval(function(){
    			   update_student_login(); 
    			}, 3000);
    			
    		
    });
</script>

<style type="text/css">
  .fa-folder-open{
    font-size: 80px;
    color: #825503db;
  }
  .fa-file{
    font-size: 50px;
    color: #822c03;
  }
  .na{
    font-size: 18px;
    font-family: Poppins;
    color: #822c03;

  }
  .bf{
    border-left: 2px solid grey;
    overflow: scroll;
  }
</style>