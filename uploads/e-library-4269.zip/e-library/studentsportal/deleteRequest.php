<?php 

require_once '../core/init.php';
require_once '../helpers/helpers.php';
		 


//delete request
    if (isset($_GET['delete'])) {
    	$deleteid = (int)$_GET['delete'];
    	$deleteid = sanitize($deleteid);
    	$updatedelete = "DELETE FROM `reference_book_grant`  WHERE id = '$deleteid' ";
    	$deletequery = $db->query($updatedelete);

    	if ($deletequery) {
    		$_SESSION['success_flash'] = 'Request deleted!';
    		header("Location: requestedBook.php");
    	}else{
    		echo "There was an error ".mysqli_error($db);
    	}
    }