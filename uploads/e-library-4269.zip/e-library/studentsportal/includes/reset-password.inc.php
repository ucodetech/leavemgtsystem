 <?php 

 if (isset($_POST['reset-request-submit'])) {
   
    $selector = bin2hex(random_bytes(8));
    $token = random_bytes(32);

    $url = "https://e-library.uzbgraphix.com.ng/studentsportal/create-new-password.php?selector=".$selector. "&validator=" . bin2hex($token);

    $expires = date("U") + 1800;

require_once  '../../core/init.php';
require_once  '../../helpers/helpers.php';


    $studentEmail = sanitize($_POST['studentEmail']);
    
   
    $sql = "DELETE FROM pwdReset WHERE pwdResetEmail = ?; ";
    $stmt = mysqli_stmt_init($db);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
      echo 'Error Occured';
      exit();
    }else {
      mysqli_stmt_bind_param($stmt, 's', $studentEmail);
      mysqli_stmt_execute($stmt);
      
    }

    $sql2 = "INSERT INTO pwdReset (pwdResetEmail,	pwdResetSelector,	pwdResetToken,	pwdResetExpires) VALUES (?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($db);
    if (!mysqli_stmt_prepare($stmt, $sql2)) {
      echo 'Error Occured';
      exit();
    }else {
      $hashedToken = password_hash($token, PASSWORD_DEFAULT);
      mysqli_stmt_bind_param($stmt, 'ssss', $studentEmail,  $selector,  $hashedToken,  $expires  );
      mysqli_stmt_execute($stmt);
      
    }
    mysqli_stmt_close($stmt);
    mysqli_close($db);

    
               require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/PHPMailer.php");
               require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/Exception.php");
               require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/SMTP.php");

               $mail =  new PHPMailer\PHPMailer\PHPMailer();
               //SMTP settings
               $mail->isSMTP();
               $mail->Host = "smtp.gmail.com";
               $mail->SMTPAuth = true;
               $mail->Username = "ucodetech.wordpress@gmail.com";
               $mail->Password =  "echo@mike12@@";
               $mail->Port = 587; //587 for tls
               $mail->SMTPSecure = "tls";
               
               //email settings
               $mail->isHTML(true);
               $mail->setFrom("ucodetech.wordpress@gmail.com");
               $mail->addAddress($studentEmail);
               $mail->addReplyTo("ucodetech.wordpress@gmail.com");
               $mail->Subject = "Password Reset Request";
               $mail->Body = "<div style='width: 80%; height: auto; border:2px solid #000; color:black; font-family: Poppins;'>
  
               <p align='center'><img src='https://e-library.uzbgraphix.com.ng/images/hg.png' class='img-fluid' width='300' alt='LMS Logo' align='center'>  </p>          
               <p style='background: #000;color: #fff; font-size: 20px; text-align: center; text-transform: uppercase;margin-top:0px'> Reset 
               Your Password</p> 
               <p  style='color: #000; font-size: 18px; text-transform:capitalize;margin:10px;  '>
               You requested for a password reset here is the link below:<br><hr>
               <a  href='".$url."' style='margin-bottom: 0;font-weight: 400;text-align: center;white-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;background-image: none;border: 1px solid transparent;padding: 6px 12px;font-size: 14px;line-height: 1.42857143;border-radius: 4px;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;  color: #fff;background-color: #d9534f;border-color: #d43f3a; text-decoration: none; font-size: 20px;'>Reset Password</a>
               <hr>
               <br> Note: if you didnt requeset for this your self please ignore this mail! thanks</p>
               <h4>e-Library</h4>
               <p style='background: #000;color: #fff; font-size:20px; text-align: center; text-transform: uppercase;'> 
               <a href='http//e-library.uzbgraphix.com.ng' style='color:#fff;'>Offical Site</a></p>
            
               </div>";
                if($mail->send())
                    header('Location: https://e-library.uzbgraphix.com.ng/studentsportal/resquest-success.php?succcess');
                else
                    echo 'something went wrong ' .$mail->ErrorInfo;
                

    
 }else{
   header("Location: https://e-library.uzbgraphix.com.ng/index.php");
 }