<?php 
require_once  '../../core/init.php';
require_once  '../../helpers/helpers.php';


    if (isset($_POST['ResetPassword'])) {

      $selector = $_POST['selector'];
      $validator = $_POST['validator'];
      $student_password = $_POST['student_password'];
      $student_confirm_password = $_POST['student_confirm_password'];


      if (empty($student_password) || empty($student_confirm_password)) {
        $_SESSION['error_flash'] = 'Password field can not be empty!';
       header('Location: https://e-library.uzbgraphix.com.ng/studentsportal/create-new-password.php');
        exit();

      }else if($student_password != $student_confirm_password) {
        $_SESSION['error_flash'] = 'Password did not match!';
        header('Location: https://e-library.uzbgraphix.com.ng/studentsportal/create-new-password.php');
          exit();
      }

      $currentDate = date("U");

      $sql = "SELECT * FROM pwdReset WHERE pwdResetSelector= '$selector' ";
      $query = $db->query($sql);
      if (!$query) {
        echo 'Error Occured';
        exit();
      }else {
        
        
        if (!$row = mysqli_fetch_assoc($query)) {
          echo 'You need to re-submit your password reset1!';
          exit();
        }else{
          $tokenBin = hex2bin($validator);
          $tokenCheck = password_verify($tokenBin, $row['pwdResetToken']);

          if ($tokenCheck === false) {
            echo 'Your request is wrong! re-submit please!2';
            exit();
          }else if ($tokenCheck === true) {
            $tokenEmail = $row['pwdResetEmail'];


            $studentSql = "SELECT * FROM students WHERE student_email_address =  '$tokenEmail'";
            $query2 = $db->query($studentSql);
           
            if (!$query2) {
              echo 'Error Occured1';
              exit();
            }else {
               

              if (!$row = mysqli_fetch_assoc( $query2)) {
                echo 'Error Occured!2';
                exit();
              }else {
                $hasdedNew = password_hash($student_password, PASSWORD_DEFAULT);
                $updatePwd = "UPDATE students SET student_password = ? WHERE student_email_address = ? ";
                $stmt = mysqli_stmt_init($db);
                if (!mysqli_stmt_prepare($stmt, $updatePwd )) {
                  echo 'Error Occured3';
                  exit();
                }else {
                  mysqli_stmt_bind_param($stmt, 'ss',$hasdedNew, $tokenEmail);
                  mysqli_stmt_execute($stmt);

                  $sql = "DELETE FROM pwdReset WHERE pwdResetEmail = ?; ";
                  $stmt = mysqli_stmt_init($db);
                  if (!mysqli_stmt_prepare($stmt, $sql)) {
                    echo 'Error Occured4';
                    exit();
                  }else {
                    mysqli_stmt_bind_param($stmt, 's', $tokenEmail);
                    mysqli_stmt_execute($stmt);
                    $_SESSION['success_flash'] = "Your Password Have been updated!";
                    header("Location: https://e-library.uzbgraphix.com.ng/studentsportal/login.php");
                  }
                }
              }
              
            }
            
          }
          
        }
        
      }

    }else{
      echo 'error!';
      header("Location: https://e-library.uzbgraphix.com.ng");
    }

 ?>