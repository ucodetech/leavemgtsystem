<?php
require_once '../core/init.php';
 require_once '../helpers/helpers.php';   
 include 'includes/head.php';

?>
   <style type="text/css">
   	label{
   		color: #fff !important;
   		font-family:Poppins !important;
   		font-weight: bolder;
   	}
   	.card-header{
   		font-size: 20px !important;
   		font-family:Poppins !important;
   	}
   </style>
            <div class="content">
                <div class="container">
	<div class="jumbotron text-center" style="margin-bottom: 0; padding: 1rem 1rem;">
    <img src="../images/hg.png" class="img-fluid" width="300" alt="LMS Logo">
		
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				
			</div>
			<div class="col-md-6" style="margin-top: 20px;">
				<div class="card bg-dark">
					<div class="card-header text-center">
						<i class="fa fa-user"></i> Student Login
					</div>
					<div class="card-body">
		<?php 
			$student_username = ((isset($_POST['student_username']))?sanitize($_POST['student_username']):'');
			 $student_username = trim($student_username);
			  $student_matric_no = ((isset($_POST['student_matric_no']))?sanitize($_POST['student_matric_no']):'');
			 $student_matric_no = trim($student_matric_no);
			 
			 $student_password = ((isset($_POST['student_password']))?sanitize($_POST['student_password']):'');
			 $student_password = trim($student_password);

			 $errors = array();

							 if ($_POST) {
 				//form validetion
 				if (empty($_POST['student_username']) || empty($_POST['student_password']) || empty($_POST['student_matric_no'])) {

 					$errors[] = 'You must provide username and password and matric No.';
 				}
 				
 					//password is more than 6 charaters
 					if (strlen($student_password )< 10) {
 						$errors[] = 'Password must be atleast 10 characters';
 					}


 				//check if username exit in the database
 				$query = $db->query("SELECT * FROM students WHERE student_username = '$student_username' AND student_matric_no = '$student_matric_no' ");
 				$student = mysqli_fetch_assoc($query);
 				$studentCount = mysqli_num_rows($query);
 				if ($studentCount < 1) {
 					$errors[] = 'student does not exit in the database';
 				}
 			if(!password_verify($student_password, $student['student_password'])) {
 					$errors[] = 'Wrong Password! Retype';
 				}

 				//check for errors
 			if (!empty($errors)) {
 				echo display_errors($errors);
 			}else{
 				// login student in
 				$student_session_id = $student['student_id'];
 				login($student_session_id);
 				
 			}
 			}

						 ?>
						<form method="post" id="student_login_form" action="login.php">
							<div class="form-group">
								<label>Matric Number:</label>
								<input type="text" name="student_matric_no" id="student_matric_no" class="form-control" >
							</div>
							<div class="form-group">
								<label>Enter Username</label>
							<input type="text" name="student_username" id="student_username" class="form-control" >
							</div>
							<div class="form-group">
								<label>Enter Password</label>
							<input type="password" name="student_password" id="student_password" class="form-control">
							</div>
							
							<div class="form-group">
							<input type="submit" name="student_login" id="student_login" value="Login" class="btn btn-info">
							<a href="reset-password.php" class="text-danger">Forgetten Password?</a>	
						</div>
						</form>
					<div align="center" class="text-light">
						Don't have an account? <a href="../register.php" class="btn btn-outline btn-success">Register</a>
					</div>
					</div>
				</div>
				
			</div>
			
		</div>

	</div>


                </div>
            </div>
<?php include 'includes/footer1.php'; ?>
<script type="text/javascript">

</script>