<?php
  include 'includes/head.php';
 header('Location: sure.php');
 

 ?>