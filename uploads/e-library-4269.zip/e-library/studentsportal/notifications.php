<?php
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
  if (!is_logged_in()) {
    login_error_redirect();
  }
  if (!has_permission_student('studentApproved')) {
    student_permission_error_redirect();
  }
    include 'includes/head.php';
    include 'includes/nav.php';

    $sql = "SELECT * FROM messages WHERE student = '$student_session_id' ORDER BY id DESC ";
    $query = $db->query($sql);

?> 
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
  
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      	<div class="row">
      		<?php 
            if (mysqli_num_rows($query) > 0) {
              while ($row = mysqli_fetch_assoc($query)){
                ?>
            <div class="col-md-6">
            <p class="alert alert-info">
              <?=$row['msg'];?>
            </p>
          </div>
          <?php if ($row['hasRead'] == 0): ?>
          <div class="col-md-3">
            <a href="read.php?read=<?=$row['id'];?>" class="btn btn-success">Click me after reading</a>
          </div>
          <?php else: ?>
            <span class="text-success"> Read </span>
          <?php endif; ?>
                <?
              }
            }else{
             ?>
             <span class="alert alert-danger">No notifications yet</span>
             <?
            }
          

            ?>
      		
      	</div>

      </div>

    </div>

  </div>

    <?php
    include 'includes/footer.php';

?>