<?php
require_once '../core/init.php';
require_once '../helpers/helpers.php';
  if (!is_logged_in()) {
    login_error_redirect();
  }
  if (!has_permission_student('studentApproved')) {
    student_permission_error_redirect();
  }
    include 'includes/head.php';
    include 'includes/nav.php';


    $sql = $db->query("SELECT * FROM students WHERE student_id = '$student_session_id' ");
    $data = mysqli_fetch_assoc($sql);
    $proId = $data['student_id'];
    $sqlimg = $db->query("SELECT * FROM studentprofile WHERE student_id = '$proId'  ");
    $img = mysqli_fetch_assoc($sqlimg);

?>          
            <div class="content-wrapper">
            <div class="content">
                <div class="container-fluid">
                    <h3 class="text-center"><?=$data['student_full_name'];?> <span class="text-info">Profile</span></h3><hr>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Profile</h4>
                                </div>
                                <div class="card-body">
                <form>
                    <div class="row">

                       
                        
                        <div class="col-md-8 pl-1">
                            <div class="form-group">
                                <label for="exampleInputEmail1 text-dark">Email address</label>
                                <input type="email" class="form-control" placeholder="Email" value="<?=$data['student_email_address'];?>" disabled="">
                            </div>
                        </div>
                   
                        <div class="col-md-6 pr-1">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$user_data['first'];?>" disabled="">
                            </div>
                        </div>
                        <div class="col-md-6 pl-1">
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$user_data['last'];?>" disabled="">
                            </div>
                        </div>
                         <div class="col-md-6 pl-1">
                            <div class="form-group">
                                <label>Reg No.</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$data['student_matric_no'];?>" disabled="">
                            </div>
                        </div>
                         <div class="col-md-6 pl-1">
                            <div class="form-group">
                                <label>Phone No.</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$data['student_phone_no'];?>" disabled="">
                            </div>
                        </div>
                         <div class="col-md-6 pl-1">
                            <div class="form-group">
                                <label>Level.</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$data['student_level'];?>" disabled="">
                            </div>
                        </div>
                         <div class="col-md-6 pl-1">
                            <div class="form-group">
                                <label>Department.</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$data['student_department'];?>" disabled="">
                            </div>
                        </div>
                         <div class="col-md-6 pl-1">
                            <div class="form-group">
                                <label>Username.</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$data['student_username'];?>" disabled="">
                            </div>
                        </div>
                    
                    </div>
                    
               
                   <!--  <a href="studentedit.php?edit=<?=$data['student_id'];?>" class="btn btn-info btn-fill pull-right">Update Profile</a> -->
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
        </div>
        <div class="col-md-4">
        <div class="card card-user">
            <div class="card-image">
                <img src="profile/ba.png" alt="banner" class="img-fluid">
            </div>
            <div class="card-body text-center">
                <div class="author">
		            <div class="image text-center">
		            <?php if ($img['status'] == 0){
		                echo "<img src='profile/profile".$proId.".jpg?'".mt_rand()."
		                 class='img-circle elevation-2' alt='User Image' width='80'>";
		            }else{
		                echo " <img src='profile/default.png' class='img-circle elevation-2' alt='User Image' width='80'>
		                        ";
		            }

             ?>

         	
       				 </div>
                    <h5 class="title"><?=$data['student_full_name'];?></h5>
                        
                    
                    <p class="description">
                        <?=$data['student_email_address'];?>
                    </p>
                </div>
                
            </div>
            <hr>
            <div class="button-container mr-auto ml-auto">
                <button href="#" class="btn btn-simple btn-link btn-icon">
                    <i class="fa fa-facebook-square"></i>
                </button>
                <button href="#" class="btn btn-simple btn-link btn-icon">
                    <i class="fa fa-twitter"></i>
                </button>
                <button href="#" class="btn btn-simple btn-link btn-icon">
                    <i class="fa fa-google-plus-square"></i>
                </button>
            </div>
        </div>
        </div>
        </div>
        <div class="container-fluid">
        	<div class="col-md-4">
                  <p class="alert alert-danger" >
                
                  Only .jpeg extsion is allowed. thanks
                
              </p>
                </div>
			<form action="update_pro.php" method="POST" enctype="multipart/form-data"> 
            	 <div class="col-md-6 form-group">
                    <label for="DOA">Student Profile Pic: <span class="text-danger">*</span></label>
                    <input type="file" name="file"  class="form-control">
                  </div>

                  <div class="col-md-4 form-group" >
                    <input type="submit" name="upload" value="Upload"  class="btn btn-success">
                  </div>
         </form>
        </div><hr>
      
        <div class="container-fluid">
             <div>
                            <?php 
                                $sqlmail = $db->query("SELECT * FROM students WHERE student_id = '$student_session_id' ");
                                 $pop = mysqli_fetch_assoc($sqlmail);
                            ?>
                            <?php 
                                
                                $student_full_name = ((isset($_POST['student_full_name']))?sanitize($_POST['student_full_name']): '');
                                 $student_email_address = ((isset($_POST['student_email_address']))?sanitize($_POST['student_email_address']): '');
                                 $student_matric_no = ((isset($_POST['student_matric_no']))?sanitize($_POST['student_matric_no']): '');
                                $msg = ((isset($_POST['msg']))?sanitize($_POST['msg']): '');
                                $errors = array();

                            if (isset($_POST['requestForm'])) {
                            	if(empty($_POST['student_full_name'])){
                            	   $errors[] = "Your Name can not be Empty!"; 
                            	}
                            		if(empty($_POST['student_email_address'])){
                            	   $errors[] = "Your email can not be Empty!"; 
                            	}
                                	if(empty($_POST['student_matric_no'])){
                            	   $errors[] = "Your Matric No can not be Empty!"; 
                            	}
                                	if(empty($_POST['msg'])){
                            	   $errors[] = "Please specify your problem!"; 
                            	}
                                
                                if(!filter_var($student_email_address, FILTER_VALIDATE_EMAIL)){
                                    $errors[] = 'Invalid Email Address';
                                }
                                
                                if(!empty($errors)){
                                    echo display_errors($errors);
                                }else{
                                				
                                $sql = "INSERT INTO `correctRequest`
                                 (student_id, student_full_name,student_matric_no,	student_email_address, problem ) VALUES
                                 (?,?,?,?,?); ";
                                $stmt = mysqli_stmt_init($db);
                                if (!mysqli_stmt_prepare($stmt, $sql)) {
                                  $errors[] = 'SQL Error';
                                }else{
                                mysqli_stmt_bind_param($stmt, "sssss",$student_session_id, $student_full_name,$student_matric_no,	$student_email_address, $msg);
                                $result =  mysqli_stmt_execute($stmt);
            
                            	        if ($result) {
                            	            ?>
                                       <div class="alert alert-success alert-dismissible fade show" role="alert">
                                          <h4 class="alert-heading">Well done!</h4>
                                          <p>Request Sent! await response!</p>
                                          <hr>
                                          <p class="mb-0">please check your email</p>
                                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                      <?
                                            	        
                            	        }else{
                            	        	echo 'error '.mysqli_error($db);
                            	        }
                                                
                                          }	
                                        
                                }
                            }
                             
                             
                             $times = $db->query("SELECT * FROM `correctRequest` WHERE student_id = '$student_session_id' ");
                             $countRow = mysqli_num_rows($times);
            
                            ?>
                        </div>
                     <h4 class="alert alert-info">Have Problems with your personal details (Request for correction) </h4 class="alert alert-info">
                         <p class="btn btn-info">
                    No of request <span class="badge badge-danger">
                     <?=$countRow;?> 
                 </span>
                </p>
                <?php 
                    if ($countRow >= 10) {
                        ?>
                         <div class="alert alert-danger alert-dismissible fade show" role="alert">
                          <h4 class="alert-heading">Well done!</h4>
                          <p>You can't request for corrections anymore the limit is 10. </p>
                          <hr>
                          <p class="mb-0">please visit the library ICT</p>
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <?
               
                      }else{
                        ?>
                        
                       
                         <form  id="request_correctionForm" method="POST" action=""> 
                <div class="row">
                 <div class="col-md-6 form-group">
                    <label for="DOA">Full Name: <span class="text-danger">*</span></label>
                    <select  name="student_full_name"  class="form-control" id="student_full_name">
                        <option value="<?=$pop['student_full_name'];?>"><?=$pop['student_full_name'];?></option>
                    </select>
                  </div>
                  <div class="col-md-6 form-group">
                    <label for="DOA">Matric No: <span class="text-danger">*</span></label>
                     <select name="student_matric_no"  class="form-control" id="student_matric_no">
                        <option value="<?=$pop['student_matric_no'];?>"><?=$pop['student_matric_no'];?></option>
                    </select>
                   
                  </div>
                  <div class="col-md-6 form-group">
                    <label for="DOA">Email: <span class="text-danger">*</span></label>
                    <select name="student_email_address"  class="form-control" id="student_email_address">
                        <option value="<?=$pop['student_email_address'];?>"><?=$pop['student_email_address'];?></option>
                    </select>
                   
                  </div>
                  <div class="col-md-6 form-group">
                    <label for="DOA">Problem:(Please hit the nail on the head) <span class="text-danger">*</span></label>
                    <input type="text" name="msg"  class="form-control" id="msg">
                    
                   
                  </div>
                  <div class="col-md-4 form-group" >
                    <input type="submit" name="requestForm" value="Request"  class="btn btn-success">

                  </div>
             <!--     <div class="form-group col-md-4 ">-->
             <!--   <span id="loader" style="display:none; margin-left: 10px;"> -->
             <!--       <img src="../preloader/ajax-loader.gif" alt="">-->

                
             <!--     </div>-->
             <!--<span id="student-errors" class="text-danger"></span>-->
             <!--   <span id="student-success" class="text-success"></span>-->

              </div>
                
         </form>
                       
                        <?
                      }
                 ?>
           
        </div>
        </div>
        </div>
    </div>
    <style type="text/css">
        label{
            color: #000 !important;
        }
    </style>
<?php include 'includes/footer.php';?>
<!--  <script type="text/javascript">-->
<!--$(document).ready(function(){-->
<!--    $('#request_correctionForm').on('submit', function(event){-->
<!--                event.preventDefault();-->
<!--                if ($('#student_full_name').val() == '') {-->
<!--                    $('#student-errors').fadeIn().html('full name  is Required!');-->
<!--                    setTimeout(function(){-->
<!--                        $('#student-errors').fadeOut('slow');-->
<!--                    }, 5000);   -->
<!--                    }-->
<!--                    else if ($('#student_email_address').val() == '') {-->
<!--                        $('#student-errors').fadeIn().html('Email address is Required!');-->
<!--                        setTimeout(function(){-->
<!--                            $('#student-errors').fadeOut('slow');-->
<!--                        }, 5000);-->
<!--                }-->
<!--                   else if ($('#student_matric_no').val() == '') {-->
<!--                        $('#student-errors').fadeIn().html('Matric No is Required!');-->
<!--                        setTimeout(function(){-->
<!--                            $('#student-errors').fadeOut('slow');-->
<!--                        }, 5000);-->
<!--                }-->
<!--                else if ($('#msg').val() == '') {-->
<!--                        $('#student-errors').fadeIn().html('Please State your problem accurately!');-->
<!--                        setTimeout(function(){-->
<!--                            $('#student-errors').fadeOut('slow');-->
<!--                        }, 5000);-->
<!--                }-->
<!--                else{-->
<!--                    $('#student-errors').html('');-->
<!--            $.ajax({-->
<!--                url:"request_correction.php",-->
<!--                method: "POST",-->
<!--                data:$('#request_correctionForm').serialize(),-->
<!--                beforeSend: function(){-->
<!--                    $("#loader").show();-->
<!--                },-->
<!--                    complete:function(){-->
<!--                            $("#loader").hide();-->
<!--                    },-->
<!--                success:function(data){-->
<!--                    $("form").trigger("reset");-->
<!--                    $('#student-success').fadeIn().html(data);-->
<!--                    setTimeout(function(){-->
<!--                        $('#student-success').fadeOut('slow');-->
<!--                    }, 5000);-->
                    
<!--                },-->
<!--                error: function(){alert('something went wrong')}-->
<!--            });-->

<!--        }-->
<!--    });-->
<!--});-->
<!--    </script>-->