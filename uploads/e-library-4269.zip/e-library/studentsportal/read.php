<?php 
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
    if (isset($_GET['read'])) {
    	$id = (int)$_GET['read'];
    	$id = sanitize($id);

    	$sql = $db->query("UPDATE messages SET hasRead = 1 WHERE id = '$id' ");
    	header("Location: notifications.php");

    }