<?php
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
  if (!is_logged_in()) {
  	login_error_redirect();
  }
  if (!has_permission_student('studentApproved')) {
  	student_permission_error_redirect();
  }
    include 'includes/head.php';
    include 'includes/nav.php';

    $sql = $db->query("SELECT * FROM reference_books ORDER BY book_categories");

    $bookquery = $db->query("SELECT * FROM reference_books ORDER BY book_id");

?>  

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
       <span class="alert alert-danger">Note: you can only request for one reference book at a time</span>
      </div><!-- /.container-fluid -->
      
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      		 <div class="table-responsive">
      			<table id="reference" class="table table-hover table-striped">
      				<thead>
      					<th>
      						Book Title
      					</th>
      					<th>
      						Author
      					</th>
      					<th>
      						Publication Date
      					</th>
      					<th>
      						Request No.
      					</th>
      				</thead>
      				<tbody>
      					<?php while($row = mysqli_fetch_assoc($sql)): ?>
      					<tr>
      						<td>
      							<?=$row['book_title'];?>
      						</td>
      						<td>
      							<?=$row['book_author'];?>
      						</td>
      						<td>
      							<?=$row['book_publication_date'];?>
      						</td>
      						<td>
      							<?=$row['request_no'];?>

      						</td>
      					</tr>
      				<?php endwhile; ?>
      				</tbody>
      			</table>
      		</div><hr>
      		<div class="container-fluid">
      		<legend>Request For Reference Book </legend>
      			<form method="post" action="request_book.php">
      				<div class="row">
					  <div class="col-md-4 form-group">
      						<label class="text-dark">Select Book Title.</label>
      						<select class="form-control" id="bkid" name="bkid">
      							<option value=""></option>
      							<?php while($refd = mysqli_fetch_assoc($bookquery)): ?>
      							<option value="<?=$refd['book_id'];?>"><?=$refd['book_title'];?></option>
      						<?php endwhile; ?>
      						</select>
      						
      					</div>
      					<div class="col-md-4 form-group">
      						<label class="text-dark">Request No.</label>
      						<input type="text" name="reno" class="form-control" placeholder="Enter Request No here">
      					</div>
      					
      				</div>
      				<div class="col-md-4 mt-10">
      						<input type="submit" name="submit" value="Request" class="btn btn-success">
      					</div>
      			</form>
      		</div>
      </div>

    </div>

  </div>

  <?php
    include 'includes/footer.php';

?>
<style type="text/css">
  .fa-folder-open{
    font-size: 80px;
    color: #825503db;
  }
  .fa-file-pdf{
    font-size: 100px;
    color: #822c03;
  }
  .na{
    font-size: 18px;
    font-family: Poppins;
    color: #822c03;

  }
</style>