<?php
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		   
  $bkid  = ((isset($_POST['bkid']))?sanitize($_POST['bkid']): '');
  $reno  = ((isset($_POST['reno']))?sanitize($_POST['reno']): '');

 
  if ($_POST) {
     $errors = array();
    $required = array('bkid', 'reno');
    foreach($required as $f) {
      if (empty($_POST[$f])) {
        $errors[] = 'All fields are required';
      }

    }
    if (!empty($errors)) {
      echo display_errors($errors);
    }else{
      $sqlcheck = $db->query("SELECT * FROM `reference_book_grant` WHERE stud_id = '$student_session_id'  ");
      if (mysqli_num_rows($sqlcheck) > 0) {
           while ($std = mysqli_fetch_assoc($sqlcheck)) {
             $studid = $std['id'];
             if (isset($studid)) {
              $sqldele= $db->query("DELETE FROM `reference_book_grant` WHERE id = '$studid'  ");
             }
           }
      }

        $sql = "INSERT INTO `reference_book_grant` (stud_id, book_id, request_id) VALUES (?,?,?) ";
        $stmt = mysqli_stmt_init($db);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
          echo  'Error in sql '.mysqli_error($db);
        }else{
          mysqli_stmt_bind_param($stmt, "sss", $student_session_id, $bkid, $reno);
          $result = mysqli_stmt_execute($stmt);
        }
    
      if ($result) {
        $_SESSION['success_flash'] = 'Request sent! await for response!(Kindly Check your email)';
        header("Location: requestedBook.php");
      }else{
        echo  'Error requesting '.mysqli_error($db);
      }
      
    }

  }
