<?php 
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 


if ($_POST) {
	$errors = array();
	$student_full_name = ((isset($_POST['student_full_name']))?sanitize($_POST['student_full_name']): '');
     $student_email_address = ((isset($_POST['student_email_address']))?sanitize($_POST['student_email_address']): '');
     $student_matric_no = ((isset($_POST['student_matric_no']))?sanitize($_POST['student_matric_no']): '');
    $msg = ((isset($_POST['msg']))?sanitize($_POST['msg']): '');
    				
                    $sql = "INSERT INTO `correctRequest`
                     (student_id, student_full_name,student_matric_no,	student_email_address, problem ) VALUES
                     (?,?,?,?,?); ";
                    $stmt = mysqli_stmt_init($db);
                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                      $errors[] = 'SQL Error';
                    }else{
                    mysqli_stmt_bind_param($stmt, "sssss",$student_session_id, $student_full_name,$student_matric_no,	$student_email_address, $msg);
                    $result =  mysqli_stmt_execute($stmt);

	        if ($result) {
	        	echo 'Request Sent! await response!';
	        }else{
	        	echo 'error '.mysqli_error($db);
	        }
                    
              }	
            
		
}
 		


