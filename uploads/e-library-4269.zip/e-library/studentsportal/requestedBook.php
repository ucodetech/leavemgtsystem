<?php
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
  if (!is_logged_in()) {
    login_error_redirect();
  }
  if (!has_permission_student('studentApproved')) {
    student_permission_error_redirect();
  }
    include 'includes/head.php';
    include 'includes/nav.php';



     $sqlcheck = $db->query("SELECT * FROM `reference_book_grant` WHERE stud_id = '$student_session_id'");
     $fetched = mysqli_fetch_assoc($sqlcheck);

     $booktitle = $fetched['book_id'];

    $sqltitle = $db->query("SELECT * FROM `reference_books` WHERE book_id = '$booktitle'");

    $rq = mysqli_fetch_assoc($sqltitle);

     

?> 
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      
       <div class="container-fluid  text-center">
        <span class="text-info">Requested Reference books will appear here</span>
        </div>
    </div><hr>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      	<div class="row">
          <div class="col-md-8">
            <?php if ($fetched['book_grant'] == 1): ?>
          <iframe  src="../books/<?=$rq['book_file'];?>" width="100%" height="700px">
      </iframe>
      <?php else: ?>
        <span class="alert alert-danger text-center"> No book Requested yet or Librarian have not approved your last request </span>

        <?php endif ?>
          </div>
          <div class="col-md-4">
            <h4>Requested book</h4>
            <ul class="nav-links">
              <?php if ($fetched): ?>
                 <li>
                <span><?=$rq['book_title'];?></span> <a href="deleteRequest.php?delete=<?=$fetched['id'];?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
              </li>
               <?php else: ?>
                no request

              <?php endif ?>

           
            </ul>
          </div>
        </div>

      </div>

    </div>

  </div>

    <?php
    include 'includes/footer.php';

?>