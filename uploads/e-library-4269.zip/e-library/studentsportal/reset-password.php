<?php

    include 'includes/head.php';

?> 

    <!-- Content Header (Page header) -->
    <div class="content-header">
      	<div class="jumbotron text-center" style="margin-bottom: 0; padding: 1rem 1rem;">
    <img src="../images/hg.png" class="img-fluid" width="300" alt="LMS Logo">
		
	</div>
       
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container">

          <form method="post"  action="includes/reset-password.inc.php">
             <p class="text-center text-info"> An email will be sent to you with an instructions on how to reset your password</p>
             <div class="row">
             
              <div class="col-md-8 form-group">
                <label class="text-info">Enter Email Address</label>
              <input type="email" name="studentEmail" id="studentEmail" class="form-control">
              </div>
              
              <div class="col-md-4 form-group">
                  <br/>
              <input type="submit" name="reset-request-submit"  value="Get Token" class="btn btn-info">
              
            </div>
            </div>
            </form>
            
            <?php 
                if(isset($_GET['error'])){
                    if($_GET['error'] == "emaildoesntexist"){
                       ?>
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                      <h4 class="alert-heading">Well done!</h4>
                      <p>The email you are inputting does not exist  in our database!</p>
                      <hr>
                      <p class="mb-0">Please check the email again</p>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                       <?
                    }
                }
                
            ?>
      </div>

    </div>

 
