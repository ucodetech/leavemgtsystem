<?php

    include 'includes/head.php';

?>
<style media="screen">
  .fa-envelope{
    font-size: 100px;
  }
</style>

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="jumbotron text-center" style="margin-bottom: 0; padding: 1rem 1rem;">
  <img src="../images/hg.png" class="img-fluid" width="300" alt="LMS Logo">
</div>

    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">

          <p class="text-success text-center">You have successfully requested for a password reset! <br>Please check your email
          for the reset link. </p>
          <h2 class="text-center text-success"><i class="fa fa-envelope"></i></h2>

      </div>

    </div>
