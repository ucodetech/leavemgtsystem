<?php
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
  if (!is_logged_in()) {
  	login_error_redirect();
  }
  if (!has_permission_student('studentApproved')) {
  	student_permission_error_redirect();
  }
    include 'includes/head.php';
    include 'includes/nav.php';

?>
   
  <?php 
   
$sql = "SELECT * FROM books ";
  $cat_id = (($_POST['cat'] != '')?sanitize($_POST['cat']): '');
  if ($cat_id == '') {
    $sql .= " WHERE book_deleted = 0";
  }else{
    $sql .= " WHERE book_categories = '{$cat_id}'  AND book_deleted = 0";
  }
  $book_title = (($_POST['book_title'] != '')?sanitize($_POST['book_title']): '');
  $book_author = (($_POST['book_author'] != '')?sanitize($_POST['book_author']): '');

$book_publication_date = (($_POST['book_publication_date'] != '')?sanitize($_POST['book_publication_date']): '');

$book_edition = (($_POST['book_edition'] != '')?sanitize($_POST['book_edition']): '');

  if ($book_title != '') {
    $sql .= " AND book_title LIKE '%{$book_title}%'";
  }
  if ($book_author != '') {
    $sql .= " AND book_author LIKE '%{$book_author}%'";

  }
   if ($book_publication_date != '') {
    $sql .= " AND book_publication_date = '{$book_publication_date}'";
  }
 if ($book_edition != '') {
    $sql .= " AND book_edition = '{$book_edition}'";
  }

  
 

  $bookQ = $db->query($sql);
  $count = mysqli_num_rows($bookQ);
  $category = get_category($cat_id);

   ?>
          <div class="content-wrapper">
            <div class="content">
                <div class="container-fluid">
                <?php if($cat_id != '') :?>
                  <h2 class="text-center"><span class="text-primary"><?=$category['book_parent'] .' <span class="text-warning">/</span> '. $category['child'] ;?></span></h2>
              <span class="alert alert-info text-center">Click the icon to access the book</span><hr>
                <?php else: ?>
                  <h2 class="text-center">Search Result (<?=$count;?>) </h2>

                <?php endif;?>
                
              <div class="row">
          <?php while ($child = mysqli_fetch_assoc($bookQ)): 
                $imgid = $child['book_id'];
        $imgsql = $db->query("SELECT * FROM book_cover WHERE book_id = '$imgid' ");
        $img = mysqli_fetch_assoc($imgsql);

            ?>
         
          <div class="col-md-3">
            <li style="list-style-type: none;">
              <span><?=$child['book_title'];?></span> <br>
              <a href="<?=$child['book_title'];?>" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-file-pdf"></i></a>
                <br>
              
            </li>
            </div>
            

            <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">
        <?php if($cat_id != '') :?>
          <ul class="breadcrumb">
        <li><a href="dashboard.php"><?=$category['book_parent'];?></a></li>
        <li><a href="all_book.php?cat=<?=$cat_id;?>"><?=$category['child'] ;?></a></li>
        <li><a><?=$child['book_title'];?></a></li>
      </ul>
      <?php else: ?>
        <ul class="breadcrumb">
      <li><a><?=$child['book_title'];?></a></li>
    </ul>
      <?php endif; ?>
          </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div><hr>
       <div class="modal-body">
        <div class="row">
         <div class="col-md-6">
              <div class="col-md-12">
                    
                <p>Book Author: <span class="text-primary"><?=$child['book_author'];?></span></p>
                  </div>
                  <div class="col-md-12">
                    <p>Book Publication Date: <span class="text-primary"><?=pretty_dates($child['book_publication_date']);?></span></p>
                  </div>
                  <div class="col-md-12">
                    <p>Book Description: <span class="text-primary"><?=$child['book_description'];?></span> </p>
                  </div>
                  
                  
         </div>
           <div class="col-md-6">
             
                  <div class="col-md-12">
                    <p>Book Cover: <br>
                      <?php if (isset($img['cover'])): ?>
                        <img src="../bookcovers/<?=$img['cover'];?>" width="50%" height="auto">
                        <?php else: ?>
                          <span class="text-danger">No cover yet</span>
                      <?php endif ?>
                    </p>

                  </div>
         </div>
        </div><hr>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a class="btn btn-primary" href="../books/<?=$child['book_file'];?>" target="_blank">Access File</a>
      </div>
    </div>
  </div>
</div>
         
             <?php endwhile; ?>
              </div>
                  
                </div>
            </div>
          </div>


           
<?php
    include 'includes/footer.php';

?>
<style type="text/css">
  .fa-folder-open{
    font-size: 80px;
    color: #825503db;
  }
  .fa-file-pdf{
    font-size: 100px;
    color: #822c03;
  }
  .na{
    font-size: 18px;
    font-family: Poppins;
    color: #822c03;

  }
</style>