
<?php
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		   include 'includes/head.php';

  if ($_POST) {
  	unset($_SESSION['LMSuser']);
  	$_SESSION['error_flash'] = 'You have logout! login again';
 	header('Location: login.php');

  }
  
 ?>
<div class="container">
    <div class="row">
      <div class="col-md-3">
        
      </div>
      <div class="col-md-6" style="margin-top: 20px;">
        <div class="card bg-dark">
          <div class="card-header text-center">
             <h3><i class="fa fa-power-off text-danger"></i> Are you sure you want to logout</h3>
          </div>
          <div class="card-body">

          	<div class="row">

 			<div class="col-md-3">
 				<form action="sure.php" method="post">
		 		<div class="form-group">
		 			<i class="fa fa-power-off i text-danger"></i> <input type="submit" name="sure" value="Yes" class="btn btn-danger">
		 		</div>
		 	</form>
 			</div>
		 	<div class="col-md-6 text-center">
		 		<div id="desktop" style="display: inline-block;">
		 		<span class="text-danger i"><i class="fa fa-arrow-left" ></i></span>	 		
				<span class="text-success i"><i class="fa fa-arrow-right" ></i></span>
		 		</div>
		 		<div id="mobile" style="display:none;">
		 		<span class="text-danger i"><i class="fa fa-arrow-up" ></i></span>	 		
				<span class="text-success i"><i class="fa fa-arrow-down" ></i></span>
		 		</div>
		 	</div>
	 		<div class="col-md-3 pull-right">
	 			<a href="dashboard.php" class="btn btn-success">No</a><i class="fa fa-plug i text-success"> </i>
	 		</div>
	 	
 			</div>

          </div>
        </div>
        
      </div>
      
    </div>

  </div>
<style type="text/css">
	.i{
		font-size: 18px;
	}
	.card{
		margin: 10% auto;
	}

@media (min-width: 320px) and (max-width: 480px) {
  #desktop{
    display: none !important;
  }
  #mobile{
  	display: block !important;
  }
  
}


</style>