<?php
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
  if (!is_logged_in()) {
    login_error_redirect();
  }
  if (!has_permission_student('studentApproved')) {
    student_permission_error_redirect();
  }
    include 'includes/head.php';
    include 'includes/nav.php';

?> 
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <?php include 'filters.php'; ?>
      </div><!-- /.container-fluid -->
       <div class="pull-right">
        <span class="text-danger">Total Books In the Library (<?=$count;?>)</span>
        </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">


      </div>

    </div>

  </div>

    <?php
    include 'includes/footer.php';

?>