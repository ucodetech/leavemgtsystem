<?php

 require_once '../core/init.php';
require_once '../helpers/helpers.php';
		 
	if($_POST['action'] == "fetch_data"){
	    $output = '';
        
	    $sql = "SELECT * FROM students WHERE student_last_login > DATE_SUB(NOW(), INTERVAL 5 SECOND);";
	   $query = $db->query($sql);
	  
	   $i = 0;
	    $output .= '
	    <h2 class="text-primary text-center">Active Users</h2>
		<table id="online" class="table table-condensed table-bordered table-striped table-hover">
			<tr>
				<th>ID</th>
				<th>Student Name</th>
				<th>Department</th>
				<th>Email Address</th>
				<th>Username</th>
				<th>Status</th>

			</tr>
			<tbody>';
	   if(mysqli_num_rows($query) > 0){
	       while($row = mysqli_fetch_assoc($query)){
	         $i = $i + 1;
	      
	      
	            $output .='
	             <tr>
	             <td>'.$i.'</td>
	                <td>'.$row["student_full_name"].'</td>
	                   <td>'.$row["student_department"].'</td>
	                   	 <td>'.$row["student_email_address"].'</td>
	                   	  <td>'.$row["student_username"].'</td>
	                   	  <td>
	                   	    <span class="btn btn-success">Online</span>
	                   	  </td>

	             </tr>
                
            
	       ';
	       
	      
	      
	       
	       }
	        $output .= '
	       </tbody> 
	       </table>';
	       
	   }

	     echo $output;    
	   
	   
	}	 
	

	   
	   
	 
		

		
