<?php 
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
		 
	if($_POST['action'] == "admin_data"){
	    $outputs = '';
        
	    $sql = "SELECT * FROM superuser WHERE super_last_login > DATE_SUB(NOW(), INTERVAL 5 SECOND)";
	   $query = $db->query($sql);
	  
	   $i = 0;
	    $outputs .= '
	    <h2 class="text-primary text-center">Active Admin</h2>
		<table id="online" class="table table-condensed table-bordered table-striped table-hover">
			<tr>
				<th>ID</th>
				<th>Admin Name</th>
				<th>Email Address</th>
				<th>Permission</th>
				<th>Status</th>

			</tr>
			<tbody>';
	   if(mysqli_num_rows($query) > 0){
	       while($row = mysqli_fetch_assoc($query)){
	         $i = $i + 1;
	      
	      
	            $outputs .='
	             <tr>
	             <td>'.$i.'</td>
	                <td>'.$row["super_full_name"].'</td>
	                   	 <td>'.$row["super_email"].'</td>
	                   	 <td>'.$row["permissions"].'</td>
	                   	  <td>
	                   	    <span class="btn btn-success">Online</span>
	                   	  </td>

	             </tr>
                
            
	       ';
	       
	      
	      
	       
	       }
	        $outputs .= '
	       </tbody> 
	       </table>';
	       
	   }

	     echo $outputs;    
	   
	   
	}	 
	

	
	 