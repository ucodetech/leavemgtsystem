<?php
       require_once '../core/init.php';
		 require_once '../helpers/helpers.php';

    if (!super_is_logged_in()) {
      super_login_error_redirect();
    }
    if (!has_permission_super('superuser')) {
      super_permission_error_redirect();
    }
    include 'includes/head.php';

?>
   
 		<style type="text/css">
    label{
      color: #fff !important;
      font-family:Poppins !important;
      font-weight: bolder;
    }
    .card-header{
      font-size: 20px !important;
      font-family:Poppins !important;
    }
   </style>
       <!-- Content Wrapper. Contains page content -->
    <!-- Content Header (Page header) -->
    <div class="content-header">
     <div class="jumbotron text-center" style="margin-bottom: 0; padding: 1rem 1rem;">
    <img src="../images/hg.png" class="img-fluid" width="300" alt="LMS Logo">
    
  </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
         <div class="container">
    <div class="row">
      <div class="col-md-3">
        
      </div>
      <div class="col-md-6" style="margin-top: 20px;">
        <div class="card bg-dark">
          <div class="card-header text-center">
            <i class="fa fa-plus"></i> Add Admin
          </div>
          <div class="card-body text-light">

        <?php 
    
        $super_full_name = ((isset($_POST['super_full_name']))?sanitize($_POST['super_full_name']): '');
        $super_email = ((isset($_POST['super_email']))?sanitize($_POST['super_email']): '');
        $super_password = ((isset($_POST['super_password']))?sanitize($_POST['super_password']): '');
        $super_confirm = ((isset($_POST['super_confirm']))?sanitize($_POST['super_confirm']): '');
        $permissions = ((isset($_POST['permissions']))?sanitize($_POST['permissions']): '');
        $errors = array();
        if ($_POST) {

            $superQuery = $db->query("SELECT * FROM superuser WHERE super_email = '$super_email' ");
            $superCount = mysqli_num_rows($superQuery);
             if ($superCount != 0 ) {
               $errors[] = 'That Super already exist in the database!';
             }

          $required = array('super_full_name', 'super_email', 'super_password', 'super_confirm', 'permissions');
          foreach ($required as $f) {
            if(empty($_POST[$f])){
     
             $errors[] = 'All field must be filled';
            }
          }

            if(strlen($super_password) < 10) {
              $errors[] = 'super_password must be atleast 10 characters!';
            }
            if ($super_password != $super_confirm) {
              $errors[] = 'super_password do not match';
            }

            if (!filter_var($super_email, FILTER_VALIDATE_EMAIL) ) {
              $errors[] = 'Invalid super_email!';
            }


          if (!empty($errors)) {
            echo display_errors($errors);
          }else{
            //add user to database
            $hashed = password_hash($super_password,PASSWORD_DEFAULT);
            $sql = "INSERT INTO superuser (super_full_name, super_email, super_password, permissions) VALUES (?,?,?,?); ";
            $stmt = mysqli_stmt_init($db);
            if (!mysqli_stmt_prepare($stmt, $sql)) {
              $errors[] = 'SQL Error';
            }else{
              mysqli_stmt_bind_param($stmt, "ssss",$super_full_name, $super_email, $hashed, $permissions );
              $result = mysqli_stmt_execute($stmt);

            if ($result) {
              $_SESSION['success_flash'] = 'successfully!';
                header('Location: superlogin.php');
            }else{
              echo 'Errors ' .mysqli_error($db);
            }

            }

              
          }
        }

      ?>


         
        <form method="POST" action="add_admin.php">         
            <div class="col-md-12 form-group">
              <label>Admin Full Name: <span class="text-danger">*</span></label>
              <input type="text" name="super_full_name" class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label>Admin super_email: <span class="text-danger">*</span></label>
              <input type="super_email" name="super_email" class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label>Admin super_password: <span class="text-danger">*</span></label>
              <input type="password" name="super_password" class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label>super_confirm_password: <span class="text-danger">*</span></label>
              <input type="password" name="super_confirm" class="form-control">
            </div>
            <div class="form-group col-md-6">
                  <label for="permissions">Permissions</label>
                  <select class="form-control" name="permissions">
                    <option value=""<?=(($permissions == '')?' selected': '');?>></option>
                    <option value="editor"<?=(($permissions == 'editor')?' selected': '');?>>Editor</option>
                    <option value="superuser,editor"<?=(($permissions == 'superuser,editor')?' selected': '');?>>Super User</option>
                  </select>
                </div>
            <div class="col-md-12 form-group">
              <a href="superusers.php" class="alert alert-danger">Cancel</a>
              <button class="btn btn-success" name="add" type="submit">Add</button>
            </div>
          
        </form>
      
          </div>
        </div>
        
      </div>
      
    </div>

  </div>

      
    </div><!-- /.container-fluid -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 

     
