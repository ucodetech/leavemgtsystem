<?php
 require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
    if (!super_is_logged_in()) {
      super_login_error_redirect();
    }
    if (!has_permission_super('superuser')) {
      super_permission_error_redirect();
    }
    include 'includes/head.php';
    include 'includes/nav.php';

?>
   
    <style type="text/css">
    label{
      color: #fff !important;
      font-family:Poppins !important;
      font-weight: bolder;
    }
    .card-header{
      font-size: 20px !important;
      font-family:Poppins !important;
    }
   </style>
       <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        search box here
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
         <div class="container">
    <div class="row">
      <div class="col-md-3">
        
      </div>
        <div class="col-md-6" style="margin-top: 20px;">
        <div class="card bg-dark">
          <div class="card-header text-center">
            <i class="fa fa-plus"></i> Add Librarain
          </div>
          <div class="card-body text-light">

        <?php 
    
        $lib_full_name = ((isset($_POST['lib_full_name']))?sanitize($_POST['lib_full_name']): '');
        $lib_email_address = ((isset($_POST['lib_email_address']))?sanitize($_POST['lib_email_address']): '');
        $lib_phone_no = ((isset($_POST['lib_phone_no']))?sanitize($_POST['lib_phone_no']): '');
        $lib_password = ((isset($_POST['lib_password']))?sanitize($_POST['lib_password']): '');
        $lib_confirm = ((isset($_POST['lib_confirm']))?sanitize($_POST['lib_confirm']): '');
        $permissions = ((isset($_POST['permissions']))?sanitize($_POST['permissions']): '');
        $errors = array();
        if ($_POST) {

            $libQuery = $db->query("SELECT * FROM `librarian` WHERE lib_email_address = '$lib_email_address' ");
            $libCount = mysqli_num_rows($libQuery);
             if ($libCount != 0 ) {
               $errors[] = 'That user already exist in the database!';
             }

          $required = array('lib_full_name', 'lib_email_address', 'lib_password', 'lib_confirm', 'permissions');
          foreach ($required as $f) {
            if(empty($_POST[$f])){
     
             $errors[] = 'All field are required!';
            }
          }

            if(strlen($lib_password) < 10) {
              $errors[] = 'lib_password must be atleast 10 characters!';
            }
            if ($lib_password != $lib_confirm) {
              $errors[] = 'lib_password do not match';
            }

            if (!filter_var($lib_email_address, FILTER_VALIDATE_EMAIL) ) {
              $errors[] = 'Invalid lib_email_address!';
            }


          if (!empty($errors)) {
            echo display_errors($errors);
          }else{
            //add user to database
            $hashed = password_hash($lib_password,PASSWORD_DEFAULT);
            $sql = "INSERT INTO `librarian` (lib_full_name, lib_phone_no, lib_email_address, lib_password, permissions) VALUES (?,?,?,?,?); ";
            $stmt = mysqli_stmt_init($db);
            if (!mysqli_stmt_prepare($stmt, $sql)) {
              $errors[] = 'SQL Error';
            }else{
              mysqli_stmt_bind_param($stmt, "sssss",$lib_full_name,$lib_phone_no, $lib_email_address, $hashed, $permissions );
              $result = mysqli_stmt_execute($stmt);

            if ($result) {
              $_SESSION['success_flash'] = 'successfully!';
                header('Location: librarains.php');
            }else{
              echo 'Errors ' .mysqli_error($db);
            }

            }

              
          }
        }

      ?>


         
        <form method="POST" action="add_librarians.php">        
            <div class="col-md-12 form-group">
              <label>Librarain Full Name: <span class="text-danger">*</span></label>
              <input type="text" name="lib_full_name" class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label>Librarain email address: <span class="text-danger">*</span></label>
              <input type="email" name="lib_email_address" class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label>Librarain Phone Number <span class="text-danger">*</span></label>
              <input type="number" name="lib_phone_no" class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label>Librarain password: <span class="text-danger">*</span></label>
              <input type="password" name="lib_password" class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label>Librarain confirm password: <span class="text-danger">*</span></label>
              <input type="password" name="lib_confirm" class="form-control">
            </div>
            <div class="form-group col-md-6">
                  <label for="permissions">Permissions</label>
                  <select class="form-control" name="permissions">
                    <option value=""<?=(($permissions == '')?' selected': '');?>></option>
                    <option value="librarian"<?=(($permissions == 'librarian')?' selected': '');?>>librarian</option>
                  </select>
                </div>
            <div class="col-md-12 form-group">
              <a href="dashboard.php" class="alert alert-danger">Cancel</a>
              <button class="btn btn-success" name="add" type="submit">Add</button>
            </div>
          
        </form>
      
          </div>
        </div>
        
      </div>
      
    </div>

  </div>

      
    </div><!-- /.container-fluid -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 
  
</div>
     
<?php include 'includes/footer.php'; ?>
