<?php
	
  $sql = "SELECT *  FROM `reference_books`";
  $query = $db->query($sql);

   ?>
           
            <h3 class="text-center">Reference Books</h3><hr>
              <div class="row">
          <?php while ($refere = mysqli_fetch_assoc($query)): 
          		$imgid = $refere['book_id'];
				$imgsql = $db->query("SELECT * FROM reference_cover WHERE book_id = '$imgid' ");
				$img = mysqli_fetch_assoc($imgsql);

          	?>

          
          <div class="col-md-4">
           
           	<span><?=$refere['book_title'];?></span> 
            <br>
           		<a href="<?=$refere['book_title'];?>" data-toggle="modal" data-target="#exampleModal">
                <i class="fa fa-file-pdf"></i>
              </a>
           		  
              
          
            </div>
            

            <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel">
        	<ul class="breadcrumb">
			  <li><a><?=$refere['book_title'];?></a></li>
			</ul>
        	</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div><hr>
      <div class="modal-body">
        <div class="row">
        	<div class="col-md-4">
              			
              	<p>Book Author: <span class="text-iprimary"><?=$refere['book_author'];?></span></p>
              		</div>
              		<div class="col-md-4">
              			<p>Book Publication Date: <span class="text-primary"><?=pretty_dates($refere['book_publication_date']);?></span></p>
              		</div>
              		<div class="col-md-4">
              			<p>Book Description: <span class="text-primary"><?=$refere['book_description'];?></span> </p>
              		</div>
              		<div class="col-md-4">
              			<p>Book Date Added: <span class="text-primary"><?=pretty_dates($refere['book_date_added']);?></span></p>
              		</div>
              		<div class="col-md-4">
              			<p>Book Time Added: <span class="text-primary"><?=pretty_datee($refere['book_date_added']);?></span></p>
              		</div>
              		<div class="col-md-4">
              			<p>Available For students: 
              				<?php if ($refere['To_be_issued'] == 0): ?>
              					<span class="text-danger">No</span>
              					<?php else: ?>
              						<span class="text-success">Yes</span>
              				<?php endif ?>
              			</p>
              		</div>
              		<div class="col-md-4">
              			<p>Book Cover: <br>
              				<?php if (isset($img['cover'])): ?>
              					<img src="../bookcovers/<?=$img['cover'];?>" width="50%" height="100px">
              					<?php else: ?>
              						<span class="text-danger">No cover yet</span>
              				<?php endif ?>
              			</p>

              		</div>
        </div><hr>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a class="btn btn-primary" href="../books/<?=$refere['book_file'];?>">Access File</a>
      </div>
    </div>
  </div>
</div>
             <?php endwhile; ?>
              </div>
             
<style type="text/css">
  .fa-folder-open{
    font-size: 80px;
    color: #825503db;
  }
  .fa-file{
    font-size: 50px;
    color: #822c03;
  }
  .na{
    font-size: 18px;
    font-family: Poppins;
    color: #822c03;

  }
  .fa-file-pdf{
    font-size: 100px;
    color: #822c03;
  }
</style>

           
