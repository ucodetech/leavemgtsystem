<?php
 require_once '../core/init.php';
require_once '../helpers/helpers.php';

//approve send mail

    if (isset($_GET['approve'])) {
      $approve_id = (int)$_GET['approve'];
      $approved = 'studentApproved'; 

      $grabemail = $db->query("SELECT * FROM students WHERE student_id = '$approve_id' ");
      $emget = mysqli_fetch_assoc($grabemail);
      $email = $emget['student_email_address'];
      $username = $emget['student_username'];
      $matricNo = $emget['student_matric_no'];

      $sql = "UPDATE students SET permissions_stud = '$approved' WHERE student_id = '$approve_id' ";
      $query = $db->query($sql);


      if ($query) {
          
              	require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/PHPMailer.php");
                require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/Exception.php");
                require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/SMTP.php");

                $mail =  new PHPMailer\PHPMailer\PHPMailer();
                //SMTP settings
                $mail->isSMTP();
                $mail->Host = "smtp.gmail.com";
                $mail->SMTPAuth = true;
                $mail->Username = "ucodetech.wordpress@gmail.com";
                $mail->Password =  "echo@mike12@@";
                $mail->Port = 587; //587 for tls
                $mail->SMTPSecure = "tls";
                
                //email settings
                $mail->isHTML(true);
                $mail->setFrom("ucodetech.wordpress@gmail.com");
                $mail->addAddress($email);
                $mail->addReplyTo("ucodetech.wordpress@gmail.com");
                $mail->Subject = "e-Library account Approval";
                $mail->Body = "<div style='width: 80%; height: auto; border:2px solid #000; color:black; font-family: Poppins;'>
   
 <p align='center'><img src='https://e-library.uzbgraphix.com.ng/images/hg.png' class='img-fluid' width='300' alt='LMS Logo' align='center'>  </p>          
 <p style='background: #000;color: #fff; font-size: 20px; text-align: center; text-transform: uppercase;margin-top:0px'>Account Approved</p> 
         <p  style='color: #000; font-size: 18px; text-transform:capitalize;margin:10px;  '>
        Your account have been approved now you can login<br>
         <a  href='https://e-library.uzbgraphix.com.ng/studentsportal/login.php'>Login</a>
         <br>Here is your username and matric no for login. password is the one you specified during registration. <span style='color:green;'> $username</span> and <span style='color:green;'> $matricNo</span>  </p>
                
 
  <p style='background: #000;color: #fff; font-size:20px; text-align: center; text-transform: uppercase;'> 
  <a href='http//e-library.uzbgraphix.com.ng' style='color:#fff;'>Offical Site</a></p>
             
</div>";
                 if($mail->send()){
                      $_SESSION['success_flash'] = 'approved!';
                    header("Location: students.php");
                     
                 } else
                     echo 'something went wrong ' .$mail->ErrorInfo;
                     
              
              }
    }






    //deapprove

     if (isset($_GET['deapprove'])) {
      $deapprove_id = (int)$_GET['deapprove'];
      
       $grabemails = $db->query("SELECT * FROM students WHERE student_id = '$deapprove_id' ");
      $emgets = mysqli_fetch_assoc($grabemails);
      $emails = $emgets['student_email_address'];
      
      $deapproved = 'notapproved';
      $sqlde = "UPDATE students SET permissions_stud = '$deapproved' WHERE student_id = '$deapprove_id' ";
      $queryde = $db->query($sqlde);
      if ($queryde) {
          $to = $emails;
              	$subject = "Account Deactivation";
              	$message = "
                        Fed.Poly e-Library
                        Your account was deactivated for some reasons. We are sorry to lock you out!
                        Visit the library for more info.
                        
                       ";
                        
              	
              	$headers = "From: info@e-library.uzbgraphix.com.ng " . "\n\r";
              	
              	mail($to, $subject, $message,$headers);
        $_SESSION['success_flash'] = 'Deapproved!';
        header("Location: students.php");
      }else{
        echo "Not Deapproved Error Occured! " . mysqli_error($db);
        header("Location: students.php?error");

      }
    }

   
    