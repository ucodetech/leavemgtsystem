<?php
 require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

  ?>
      <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
    <h2 class="text-center">Archives</h2>
        <?php
   $sql = "SELECT * FROM books  WHERE book_deleted = 1 ";
   $delete = $db->query($sql);

   if (isset($_GET['restore'])) {
     $restore_id = (int)$_GET['restore'];
      $BookResults = $db->query("UPDATE books SET book_deleted = 0 WHERE book_id = '$restore_id'");
      if ($BookResults) {
        $_SESSION['success_flash'] = 'File restored';
      if (!headers_sent()) {
         header("Location: archive.php");
      }
      }else{
        echo 'error'.mysqli_error($db);
       header("Location: archive.php");
      }
      }
      
      if (isset($_GET['deleteBook'])) {
     $deleteBook_id = (int)$_GET['deleteBook'];
     $book_url = '../books/'.$deleteBook_id['book_file'];
        unlink($book_url);
      $BooksResults = $db->query("UPDATE books SET book_deleted = '' WHERE book_id = '$deleteBook_id'");
    $_SESSION['success_flash'] = 'File deleted permanently';
      header("Location: archive.php");

      }

?>
  <h2 class="text-center text-danger">Restore or Delete Files Permanently</h2>
<hr>
<table  id="archiveT" class="table table-bordered table-condensed table-striped">
  <thead>
    <th>Controls</th><th>Book Title</th><th>Book Author</th><th>Date Added</th>
  </thead>
  <tbody>

    <?php while($Book = mysqli_fetch_assoc($delete)) :

      ?>
    <tr>
      <td>
        <a href="archive.php?restore=<?=$Book['book_id'];?> " class="btn btn-success btn-sm">
        <i class="fa fa-recycle"></i></a>
      
        <a href="archive.php?deleteBook=<?=$Book['book_id'];?> " class="btn btn-danger btn-sm">
        <i class="fa fa-trash"></i> </a>
      </td>
      <td><?=$Book['book_title'];?></td>
      <td><?=$Book['book_author'];?></td>
      <td><?=$Book['book_date_added'];?></td>

    </tr>
  <?php endwhile;?>
  </tbody>
</table>
      
    </div><!-- /.container-fluid -->
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
</div>
 
 

  <?php include 'includes/footer.php';