<?php
 require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';
?>

   <div class="content-wrapper">
    <div class="content">
        <div class="container-fluid">
        	  <legend class="text-center">Book Categories</legend><hr>
        	  <div class="row">
        	  	<!-- form -->
        	  	<div class="col-md-6">
        	  		<?php 
        // Edit category
        	  		$book_parent = '';
        	if (isset($_GET['edit']) && !empty($_GET['edit'])) {
        		$edit_id = (int)$_GET['edit'];
        		$edit_id = sanitize($edit_id);
        		$edit_sql = "SELECT * FROM book_categories WHERE cat_id = '$edit_id' ";
        		$edit_query = $db->query($edit_sql);
        		$edit_categroy = mysqli_fetch_assoc($edit_query);

        	}
        //delete book category
        if (isset($_GET['delete']) && !empty($_GET['delete'])) {
        	$delete_id = (int)$_GET['delete'];
        	$delete_id = sanitize($delete_id);
        	$sqls = "SELECT * FROM book_categories WHERE cat_id = '$delete_id' ";
        	$resultd = $db->query($sqls);
        	$category = mysqli_fetch_assoc($resultd);
        	if ($category['book_parent'] == 0) {
        		$sqldd = "DELETE FROM book_categories WHERE cat_id ='$delete_id' ";
        		$db->query($sqldd);
        	}
        	$dsql = "DELETE FROM book_categories WHERE cat_id = '$delete_id' ";
        	$dquery = $db->query($dsql);
        	if (!headers_sent()) {
			   header("Location: book_categories.php");
			    exit;
			}
        	
        }

    $sql = "SELECT * FROM `book_categories` WHERE book_parent = 0 ";
    $query = $db->query($sql);
    $errors = array();
    $category = '';
    //process form
    if (isset($_POST) && !empty($_POST)) {
    	$book_parent= sanitize($_POST['book_parent']);
    	$category = sanitize($_POST['category']);
    	$sqlform = "SELECT * FROM book_categories WHERE category = '$category' AND book_parent = '$book_parent' ";
    	if (isset($_GET['edit'])) {
    		$id = $edit_categroy['cat_id'];
    		$sqlform = "SELECT * FROM book_categories WHERE category = '$category' AND book_parent = '$book_parent' AND cat_id != '$id' ";
    	}
    	$fresult = $db->query($sqlform);
    	$count = mysqli_num_rows($fresult);

    	//if category is blank
    	if ($category == '') {
    		$errors[] .= 'The book category cant be empty';
    	}
    	// if category exit
    	if ($count > 0) {
    		$errors[] .=$category . ' already exits. Please chose a new book category';
    	}

    	// display errors or update database
    	if (!empty($errors)) {
    		//display errors
    		echo  display_errors($errors);
    		 
			 }else{
    		//update database
			 	$updatesql = "INSERT INTO book_categories
			 	 (category, book_parent) 
			 	 VALUES 
			 	('$category', '$book_parent')";
			 	if (isset($_GET['edit'])) {
			 		$updatesql =  "UPDATE book_categories SET category = '$category', book_parent = '$book_parent' WHERE cat_id = '$edit_id' ";
			 	}
			 	$db->query($updatesql);
			 	if (!headers_sent()) {
			   header("Location: book_categories.php");
			    exit;
			}
    			}
    		}
    		$category_value = '';
    		$parent_value = 0;
    		if (isset($_GET['edit'])) {
    			$category_value = $edit_categroy['category'];
    			$parent_value = $edit_categroy['book_parent'];
    		}else{
    			if (isset($_POST)) {
    				$category_value = $category;
    				$parent_value = $book_parent;
    			}
    		}

?>
        	  		<legend><?=((isset($_GET['edit']))?'Edit':'Add A');?> Book Category</legend><hr>
        	  		<div id="errors"></div>
        	  		<form class="form" action="book_categories.php<?=((isset($_GET['edit']))?'?edit='.$edit_id:'');?>" method="post">
        	  			<div class="form-group">
        	  				<label>Book Parent</label>
        	  				<select class="form-control"  name="book_parent" id="book_parent">
        	  					<option value="0"<?=(($parent_value == 0)?'selected="selected"':'')?>>Book Parent</option>
        	  					<?php while($parent = mysqli_fetch_assoc($query)): ?>
        	  						<option value="<?=$parent['cat_id'];?>"<?=(($parent_value == $parent['cat_id'])?'selected="selected"':'');?>><?=$parent['category'];?></option>
        	  					<?php endwhile; ?>
        	  				</select>
        	  			</div>
        	  			<div class="form-group">
        	  				<label>Book Category</label>
        	  				<input type="text" name="category" id="category" 
        	  				value="<?=$category_value;?>" class="form-control">
        	  			</div>
        	  			<div class="form-group">
        	  				<input type="submit" name="" class="btn btn-success" value="<?=((isset($_GET['edit']))?'Edit':'Add A');?> Book Category">
        	  			</div>
        	  		</form>
        	  	</div>
        	  	<!-- end of form -->
        	  	<div class="col-md-6">
        	  		<table id="cate"  class="table table-bordered text-light">
        	  			<thead class="bg-danger">
        	  				<th class="text-light">Book Category</th><th class="text-light">Book Parent</th><th class="text-light">Controls</th>
        	  			</thead>
        	  			<tbody>
        	  				<?php
        	  				 $sql = "SELECT * FROM `book_categories` WHERE book_parent = 0 ";
   							 $query = $db->query($sql);

        	  				 while($parent = mysqli_fetch_assoc($query)) :
        	  				 	$parent_id = (int)$parent['cat_id'];
        	  				 	$sql2 = "SELECT * FROM book_categories WHERE book_parent = $parent_id ";
        	  				 	$cresult = $db->query($sql2);

        	  				?>
        	  				<tr class="bg-primary">
        	  					<td><?=$parent['category'];?></td>
        	  					<td>Book Parent</td>
        	  					<td>
        	  						<a href="book_categories.php?edit=<?=$parent['cat_id'];?>" class="btn btn-xs btn-success"><i class="fa fa-edit"></i></a>
        	  						<a href="book_categories.php?delete=<?=$parent['cat_id'];?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
        	  					</td>
        	  				</tr>
        	  				<?php  while($child = mysqli_fetch_assoc($cresult)) : ?>
        	  				<tr class="bg-info">
        	  					<td><?=$child['category'];?></td>
        	  					<td><?=$parent['category'];?></td>
        	  					<td>
        	  						<a href="book_categories.php?edit=<?=$child['cat_id'];?>" class="btn btn-xs btn-success"><i class="fa fa-edit"></i></a>
        	  						<a href="book_categories.php?delete=<?=$child['cat_id'];?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
        	  					</td>
        	  				</tr>
        	  			<?php endwhile; ?>
        	  			<?php endwhile; ?>
        	  			</tbody>
        	  		</table>
        	  	</div>
        	  </div>
          
        </div>
    </div>
</div>
           
<?php
    include 'includes/footer.php';

?>
