<?php
 require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

?>    
  <style type="text/css">
  	p{
  		font-size: 20px;
  		font-family: Poppins;
  	}
  </style>
    <div class="content-wrapper">
            <div class="content">
                <div class="container">
                
                	<?php 
                	if (isset($_GET['detials'])){
                		$bookid = (int)$_GET['detials'];
                		$bookid = sanitize($bookid);

                		$sql = "SELECT * FROM books WHERE book_id = '$bookid' AND book_deleted = 0 ";
                		$query = $db->query($sql); 
                		
                		$result = mysqli_fetch_assoc($query);
						  $file = $result['book_file'];
						  $path = '../books/';
						  $doc = $path.$file;
						  $imgid = $result['book_id'];
						$imgsql = $db->query("SELECT * FROM book_cover WHERE book_id = '$imgid' ");
						$img = mysqli_fetch_assoc($imgsql);
						$category = get_category($bookid);

						
                		
                	}

                		?>
              <h4 class="text-center text-info"> <span class="text-primary"><?=$result['book_title'];?> </span> </h4> <hr>
                	<div class="row">
         			
              		<div class="col-md-4">
              			<p>Book Title: <span class="text-info"><?=$result['book_title'];?></span></p>
              		</div>
              		<div class="col-md-4">
              			<p>Book Author: <span class="text-info"><?=$result['book_author'];?></span></p>
              		</div>
              		<div class="col-md-4">
              			<p>Book Publication Date: <span class="text-info"><?=pretty_dates($result['book_publication_date']);?></span></p>
              		</div>

              		<div class="col-md-3">
              			<p>Book Description: <span class="text-info"><?=$result['book_description'];?></span> </p>
              		</div>
              		<div class="col-md-3">
              			<p>Book Date Added: <span class="text-primary"><?=pretty_dates($result['book_date_added']);?></span></p>
              		</div>
              		<div class="col-md-3">
              			<p>Book Time Added: <span class="text-primary"><?=pretty_datee($result['book_date_added']);?></span></p>
              		</div>
              		<div class="col-md-3">
              			<p>Available For students: 
              				<?php if ($result['To_be_issued'] == 0): ?>
              					<span class="text-danger">No</span>
              					<?php else: ?>
              						<span class="text-success">Yes</span>
              				<?php endif ?>
              			</p>
              		</div>
              		<div class="col-md-6">
              			<p>Book Cover: <br>
              				<?php if (isset($img['cover'])): ?>
              					<img src="../bookcovers/<?=$img['cover'];?>" width="50%" height="300px">
              					<?php else: ?>
              						<span class="text-danger">No cover yet</span>
              				<?php endif ?>
              			</p>

              		</div>
              		<div class="col-md-6">
              			Preview: <hr>	
              			<a href="<?=$doc;?>" target="_blank" class="btn btn-success">View Book</a><hr>
              			
						<iframe  src="<?=$doc;?>" width="90%" height="500px">
						</iframe>
              			
              		</div>
              	
              </div>
                  
      			<a href="books.php" class="text-danger"> <<-Back </a>
              
                </div>
            </div>
          </div>
           
<?php
    include 'includes/footer.php';

?>