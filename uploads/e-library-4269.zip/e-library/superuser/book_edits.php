<?php
 require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
// make aviable to student
    if (isset($_GET['To_be_issued'])) {
      $id = (int)$_GET['book_id'];
      $To_be_issued = (int)$_GET['To_be_issued'];
      $issuedSql = "UPDATE reference_books SET To_be_issued = '$To_be_issued' WHERE book_id = '$id' ";
      $issuedQuery = $db->query($issuedSql);
      header("Location: reference_books.php");
    }
    //delete functions
 if (isset($_GET['delete'])){
  $id = (int)$_GET['delete'];
  $id = sanitize($id);
    $db->query("UPDATE `reference_books` SET book_deleted = 1 WHERE book_id = '$id' ");
      $_SESSION['success_flash'] = 'Removed! check archive for restore!';
        header("Location: reference_books.php");
    }
    //edit functions
    if (isset($_GET['edit'])) {
   
    $book_title = ((isset($_POST['book_title']) && $_POST['book_title'] != '')?sanitize($_POST['book_title']): '');
    $book_author = ((isset($_POST['book_author']) && $_POST['book_author'] != '')?sanitize($_POST['book_author']): '');
    $book_publication_date = ((isset($_POST['book_publication_date']) && $_POST['book_publication_date'] != '')?sanitize($_POST['book_publication_date']): '');
    $book_description = ((isset($_POST['book_description']) && $_POST['book_description'] != '')?sanitize($_POST['book_edition']): '');
    $book_edition = ((isset($_POST['book_edition']) && $_POST['book_edition'] != '')?sanitize($_POST['book_edition']): '');

    $category = ((isset($_POST['child']) && $_POST['child'] != '')?sanitize($_POST['child']): '');
    $book_parent = ((isset($_POST['book_parent']) && $_POST['book_parent'] != '')?sanitize($_POST['book_parent']): '');
    $saved_book = '';

  
  $parentQuery = $db->query("SELECT * FROM book_categories WHERE book_parent = 0 ORDER BY category ");
   $errors = array();
    $dbpath = '';


    if (isset($_GET['edit'])) {
      $edit_id = (int)$_GET['edit'];
      $editQuery = $db->query("SELECT * FROM reference_books WHERE book_id = '$edit_id' ");
      $books = mysqli_fetch_assoc($editQuery);
           //book cover 
        if (isset($_GET['delete_book'])) {
        $book_url = '../books/'.$books['book_file'];
        unlink($book_url);
        $db->query("UPDATE reference_books SET book_file = '' WHERE book_id = '$edit_id' ");
        header('Location: book_edit.php?edit='.$edit_id);
      }
      $book_title = ((isset($_POST['book_title']) && !empty($_POST['book_title']))?sanitize($_POST['book_title']):$books['book_title']);
      $book_author = ((isset($_POST['book_author']) && !empty($_POST['book_author']))?sanitize($_POST['book_author']):$books['book_author']);
      $book_publication_date = ((isset($_POST['book_publication_date']) && !empty($_POST['book_publication_date']))?sanitize($_POST['book_publication_date']):$books['book_publication_date']); 
      $book_description = ((isset($_POST['book_description']) && !empty($_POST['book_description']))?sanitize($_POST['book_description']):$books['book_description']);
      $book_edition = ((isset($_POST['book_edition']) && !empty($_POST['book_edition']))?sanitize($_POST['book_edition']):$books['book_edition']);

      $category = ((isset($_POST['child']) && $_POST['child'] != '')?sanitize($_POST['child']):$books['book_categories']);
      $parentQ = $db->query("SELECT * FROM book_categories WHERE cat_id = '$category' ");
    $parentResult = mysqli_fetch_assoc($parentQ);
      $book_parent = ((isset($_POST['book_parent']) && !empty($_POST['book_parent']))?sanitize($_POST['book_parent']):$parentResult['book_parent']); 
    $saved_book = (($books['book_file'] != '')?$books['book_file']: '');
     $dbpath = $saved_book;



    }


      if ($_POST) {

      if (empty($_POST['book_title'])) {
      $errors[] = 'Book Title is required!';
    }
    if (empty($_POST['book_author'])) {
      $errors[] = 'Book Author is required!';
    }
    if (empty($_POST['book_publication_date'])) {
      $errors[] = 'Book Publication Date is required!';
    }
    if (empty($_POST['book_description'])) {
      $errors[] = 'Book Description is required!';
    }
    if (empty($_POST['book_parent'])) {
      $errors[] = 'Book Parent Category is required!';
    }
    if (empty($_POST['child'])) {
      $errors[] = 'Book Child Category is required!';
    }
     if (empty($_POST['book_edition'])) {
      $errors[] = 'Book Edition is required!';
    }
    $date = date('Y');
     date_default_timezone_set("Africa/Lagos");
      $dt = new DateTime();
      $time =  $dt->format('h:i:sa');
 
     if (!empty($_FILES)) {
      $file =$_FILES['book_file'];
      $name = $file['name'];
      $nameArray = explode('.', $name);
      $fileName = $nameArray[0];
      $fileExt = $nameArray[1];
      $fileType = $file['type'];
      $tmpLoc = $file['tmp_name'];
      $fileSize = $file['size'];
      $fileError = $file['error'];
      $allowed  = array('pdf','doc', 'docx', 'odt', 'ppt' );
      $uploadName = 'reference_'.$fileName.$time.'.'.$fileExt;
      $uploadPath ='../books/'.$uploadName;
      $dbpath = $uploadName;
  
      if (!in_array($fileExt, $allowed )) {
          $errors[] ='The file extension not supported!';
      }
      if ($fileSize > 150000000) {
        $errors[]  ='The file size must be blow 15MB.';
      }
      if ($fileError != 0) {
        $errors[] = 'File is required';
      }
    
    }
    if (!empty($errors)) {
            echo display_errors($errors);
     }else{

          if (!empty($_FILES)) {
          move_uploaded_file($tmpLoc, $uploadPath);
      }
       $sql = "UPDATE  `books` SET book_title = ?, book_author = ?, book_publication_date = ?, book_file = ?, book_description = ?, book_categories = ?, book_edition = ? WHERE book_id = '$edit_id' ";
        $stmt = mysqli_stmt_init($db);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
        $errors[] = 'SQL Error';
        }else{
        mysqli_stmt_bind_param($stmt, "sssssss", $book_title, $book_author, $book_publication_date, $dbpath, $book_description,  $category, $book_edition);
        $result =  mysqli_stmt_execute($stmt);

        }
             
        if ($result) {
        $_SESSION['success_flash'] = "Update Successful";
        header("Location: reference_books.php");
        
        }else {
        echo "something went wrong!".mysqli_error($db);
      }

       }    
      

      }


}
?>
   

      <div class="content">
        <div class="container-fluid">
          <h2 class="text-center">Edit Book</h2>
      <hr>
      <div class="card bg-dark">
          <div class="card-header text-center">
            <i class="fa fa-plus"></i> Edit Book
          </div>
          <div class="card-body">
            <form action="book_edits.php?<?=((isset($_GET['edit']))?'edit='.$edit_id:'');?>" method="POST" enctype="multipart/form-data">
        <div class="row">
          <div class="col-md-4 form-group">
            <label class="text-light">Book Title :<span class="text-danger">*</span></label>
            <input type="text" name="book_title" id="book_title"  value="<?=$book_title;?>" class="form-control">
          </div>
          <div class="col-md-4 form-group">
            <label class="text-light">Book Author :<span class="text-danger">*</span></label>
            <input type="text" name="book_author" id="book_author" value="<?=$book_author;?>"  class="form-control">
          </div>
          <div class="col-md-4 form-group">
            <label class="text-light">Book Publication Date :<span class="text-danger">*</span></label>
            <input type="date" name="book_publication_date" value="<?=$book_publication_date;?>"  id="book_publication_date" class="form-control">
          </div>
          <div class="col-md-4 form-group">
            <label class="text-light">Book Edition :<span class="text-danger">*</span></label>
            <input type="text" name="book_edition" value="<?=$book_edition;?>" id="book_edition" class="form-control">
          </div>
          <div class="col-md-4 form-group">
            <label class="text-light"> Current Book:<span class="text-danger">*</span></label>
            <?php if ($saved_book != ''): ?>
              <div class="saved_book">
             <input type="disabled" disabled name="book_file" id="book_file" class="form-control" value="<?=$saved_book;?>"><br>
             <a href="book_edit.php?delete_book=1&edit=<?=$edit_id;?>" class="btn btn-danger">Delete</a>
              </div>
              <?php else: ?>
                <label class="text-light">Book File (PDF, DOCS, PPT):<span class="text-danger">*</span></label>
            <input type="file" name="book_file" id="book_file" class="form-control">
            <?php endif ?>
          </div>
          <div class="form-group col-md-4">
            <label class="text-light">Book Description :<span class="text-danger">*</span></label>
            <textarea name="book_description" id="book_description" class="form-control" rows="6">
              <?=$book_description;?>
            </textarea>
          </div>
          <div class="col-md-4 form-group">
            <label class="text-light">Book Parent Category:<span class="text-danger">*</span></label>
            <select name="book_parent" id="book_parent" class="form-control">
              <option value=""<?=(($book_parent == '')?'selected':'');?>></option>
              <?php while($b_parent = mysqli_fetch_assoc($parentQuery)): ?>
              <option value="<?=$b_parent['cat_id'];?>"<?=(($book_parent == $b_parent['cat_id'])?'selected':'');?>><?=$b_parent['category'];?></option>
                <?php endwhile ?>
            </select>
          </div>
          <div class="col-md-4 form-group">
            <label class="text-light">Book Child Category:<span class="text-danger">*</span></label>
            <select name="child" id="child" class="form-control">
              
            </select>
          </div>
          
          <div class="col-md-4 form-group">
            <a href="reference_books.php" class="btn btn-warning pull-right">Cancel Editing</a>
            <input type="submit" name="" value="<?=((isset($_GET['edit']))?'Edit ':'');?> Book" class="btn btn-success">
          </div>
        </div>
        
      </form>
          </div>
      </div>
        </div>
      </div>


           
<?php
    include 'includes/footer.php';

?>

<script type="text/javascript">
  jQuery('document').ready(function(){
    get_child_options('<?=$category;?>');
  });
</script>