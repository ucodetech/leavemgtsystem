<?php
 require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';
?>

<?php 

 if (isset($_GET['add'])) {
 	$parentQuery = $db->query("SELECT * FROM book_categories WHERE book_parent = 0 ORDER BY category ");
 	if ($_POST) {
 	$book_title  = ((isset($_POST['book_title']))?sanitize($_POST['book_title']): '');
 	$book_author  = ((isset($_POST['book_author']))?sanitize($_POST['book_author']): '');
 	$book_publication_date  = ((isset($_POST['book_publication_date']))?sanitize($_POST['book_publication_date']): '');
 	$book_description  = ((isset($_POST['book_description']))?sanitize($_POST['book_description']): '');
 	$book_categories  = ((isset($_POST['child']))?sanitize($_POST['child']): '');
 	$book_edition = ((isset($_POST['book_edition']))?sanitize($_POST['book_edition']): '');
 		$errors = array();
 		$dbpath = '';
 		if (empty($_POST['book_title'])) {
 			$errors[] = 'Book Title is required!';
 		}
 		if (empty($_POST['book_author'])) {
 			$errors[] = 'Book Author is required!';
 		}
 		if (empty($_POST['book_publication_date'])) {
 			$errors[] = 'Book Publication Date is required!';
 		}
 		if (empty($_POST['book_description'])) {
 			$errors[] = 'Book Description is required!';
 		}
 		if (empty($_POST['book_parent'])) {
 			$errors[] = 'Book Parent Category is required!';
 		}
 		if (empty($_POST['child'])) {
 			$errors[] = 'Book Child Category is required!';
 		}
    	if (empty($_POST['book_edition'])) {
      		$errors[] = 'Book Edition is required!';
   		}

    	$date = date('Y');
     date_default_timezone_set("Africa/Lagos");
      $dt = new DateTime();
      $time =  $dt->format('h:i:sa');
 
     if (!empty($_FILES)) {
      $file =$_FILES['book_file'];
      $name = $file['name'];
      $nameArray = explode('.', $name);
      $fileName = $nameArray[0];
      $fileExt = $nameArray[1];
      $fileType = $file['type'];
      $tmpLoc = $file['tmp_name'];
      $fileSize = $file['size'];
      $fileError = $file['error'];
      $allowed  = array('pdf');
      $uploadName = $fileName.$time.'.'.$fileExt;
      $uploadPath ='../books/'.$uploadName;
      $dbpath = $uploadName;
  
      if (!in_array($fileExt, $allowed )) {
          $errors[] ='The file extension not supported!';
      }
      if ($fileSize > 150000000) {
        $errors[]  ='The file size must be blow 15MB.';
      }
      if ($fileError != 0) {
      	$errors[] = 'File is required';
      }
    
    }
    	if (!empty($errors)) {
      echo display_errors($errors);
    }else{
    	if (!empty($_FILES)) {
    		  move_uploaded_file($tmpLoc, $uploadPath);
    	}
    	$hasnot = 0;
    	 $sql = "INSERT INTO  `books`
				(book_title, book_author, book_publication_date, book_file, book_description, book_categories, hasCover, book_edition) VALUES 
				(?,?,?,?,?,?,?,?); ";
				$stmt = mysqli_stmt_init($db);
				if (!mysqli_stmt_prepare($stmt, $sql)) {
				$errors[] = 'SQL Error';
				}else{
				mysqli_stmt_bind_param($stmt, "ssssssss", $book_title, $book_author, $book_publication_date, $dbpath, $book_description, $book_categories, $hasnot, $book_edition);
				$result =  mysqli_stmt_execute($stmt);

				}
				     
				if ($result) {
				$_SESSION['success_flash'] = "Added Successfully";
				if (!headers_sent()) {
					header("Location: books.php");
				}
				}else {
				echo "something went wrong!".mysqli_error($db);
				 }

				}

 	}		
  ?>
  <div class="content-wrapper">
    	<div class="content">
    		<div class="container-fluid">
    			<h2 class="text-center">Add A New Book</h2>
    	<hr>
    	<div class="card bg-dark">
          <div class="card-header text-center">
            <i class="fa fa-plus"></i> Add A New Book
          </div>
          <div class="card-body">
          	<form action="books.php?add=1" method="POST" enctype="multipart/form-data">
    		<div class="row">
    			<div class="col-md-4 form-group">
    				<label class="text-light">Book Title :<span class="text-danger">*</span></label>
    				<input type="text" name="book_title" id="book_title" class="form-control">
    			</div>
    			<div class="col-md-4 form-group">
    				<label class="text-light">Book Author :<span class="text-danger">*</span></label>
    				<input type="text" name="book_author" id="book_author" class="form-control">
    			</div>
    			<div class="col-md-4 form-group">
    				<label class="text-light">Book Publication Date :<span class="text-danger">*</span></label>
    				<input type="date" name="book_publication_date" id="book_publication_date" class="form-control">
    			</div>
    			<div class="col-md-4 form-group">
    				<label class="text-light">Book Edition :<span class="text-danger">*</span></label>
    				<input type="text" name="book_edition" id="book_edition" class="form-control">
    			</div>
    			<div class="col-md-4 form-group">
    				<label class="text-light">Book File (PDF):<span class="text-danger">*</span></label>
    				<input type="file" name="book_file" id="book_file" class="form-control">
    			</div>
    			<div class="form-group col-md-4">
    				<label class="text-light">Book Description :<span class="text-danger">*</span></label>
    				<textarea name="book_description" id="book_description" class="form-control" rows="6">
    					
    				</textarea>
    			</div>
    			<div class="col-md-4 form-group">
    				<label class="text-light">Book Parent Category:<span class="text-danger">*</span></label>
    				<select name="book_parent" id="book_parent" class="form-control">
    					<option value=""<?=((isset($_POST['book_parent']) && $_POST['book_parent'] == '')?'selected':'');?>></option>
    					<?php while($book_parent = mysqli_fetch_assoc($parentQuery)): ?>
    					<option value="<?=$book_parent['cat_id'];?>"<?=((isset($_POST['book_parent']) && $_POST['book_parent'] == $book_parent['cat_id'])?'selected':'');?>><?=$book_parent['category'];?></option>
    						<?php endwhile ?>
    				</select>
    			</div>
    			<div class="col-md-4 form-group">
    				<label class="text-light">Book Child Category:<span class="text-danger">*</span></label>
    				<select name="child" id="child" class="form-control">
    					
    				</select>
    			</div>
    			
    			<div class="col-md-4 form-group">
    				<a href="books.php" class="btn btn-warning pull-right">Cancel</a>
    				<input type="submit" name="add" value="Add Book" class="btn btn-success">
    			</div>
    		</div>
    		
    	</form>
          </div>
      </div>
    		</div>
    	</div>
    </div>



<?php } else{

?>
<div class="content-wrapper">
<div class="content">
    <div class="container-fluid">
    	<?php 
    		$sql = "SELECT * FROM `books` WHERE book_deleted = 0  ";
    		$bresults = $db->query($sql);
    	 ?>
    	 <h2 class="text-center">Books</h2>
    	  <a href="books.php?add=1" id="book_btn" class="btn btn-info pull-right">Add Books</a>
    	 <hr> 
    	 <div class="clear-fix"></div>
       <div class="table-responsive">
		<table id="books" class="table table-condensed table-bordered table-striped table-hover">
			<thead>
				<th>Book Title</th>
				<th>Book Author</th>
				<th>Book Category</th>
				<th>Date Added</th>
				<th>To be Issued for Student</th>
				<th>Full Details</th>
				<th>Make available for student</th>
				<th>Has Cover</th>
				<th>Controls</th>

			</thead>
			<tbody>
				<?php 
				while($books = mysqli_fetch_assoc($bresults)): 
					$childID = $books['book_categories'];
					$catsql = "SELECT * FROM book_categories WHERE cat_id = '$childID' ";
					$result = $db->query($catsql);
					$child = mysqli_fetch_assoc($result);
					$parentID = $child['book_parent'];
					$psql = "SELECT * FROM book_categories WHERE cat_id = '$parentID' ";
					$presult = $db->query($psql);
					$parent = mysqli_fetch_assoc($presult);
					
					?>
				<tr>
					
					<td><?=$books['book_title'];?></td>
					<td><?=$books['book_author'];?></td>
					<td>
						<span class="text-primary"><?=$parent['category'];?></span> -- 
						<span class="text-info"><?=$child['category'];?></span>
						
					</td>
					<td><?=pretty_date($books['book_date_added']);?></td>
					<td>
						<?php if ($books['To_be_issued'] == 0): ?>
							<span class="text-danger">No</span>
							<?php else: ?>
								<span class="text-success">Yes</span>
						<?php endif ?>
					</td>
					
					<td>
						<a href="book_details.php?detials=<?=$books['book_id'];?>" class="btn btn-sm btn-success">Book Details</a>
					</td>
					<td>
						<a href="book_edit.php?To_be_issued=<?=(($books['To_be_issued'] == 0)?'1':'0');?>&book_id=<?=$books['book_id'];?>" class="btn btn-sm btn-primary"><i class="fa fa-<?=(($books['To_be_issued']==1)?'minus':'plus');?>"></i>
							&nbsp; <?=(($books['To_be_issued'] == 1)?'Available': 'Not Available');?>
						</a>
					</td>
					<td>
						<?php if ($books['hasCover'] == 1): ?>
							<span class="text-primary">Yes Book has cover</span>
							<?php else: ?>
								<span class="text-danger">No cover yet</span>
						<?php endif ?>
					</td>
            
					<td>
						<a href="book_edit.php?edit=<?=$books['book_id'];?>" class="btn btn-sm btn-success"><i class="fa fa-edit"></i></a>
						<a href="book_edit.php?delete=<?=$books['book_id'];?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
					</td>
					
				</tr>






			<?php endwhile; ?>
			</tbody>
		</table>
  </div>
      
    </div>
</div>
</div>

	<?php }include 'includes/footer.php'; ?>
<script type="text/javascript">
  jQuery('document').ready(function(){
    get_child_options('<?=$category;?>');
  });
</script>


