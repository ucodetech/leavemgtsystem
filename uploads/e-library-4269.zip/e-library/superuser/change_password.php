<?php
 require_once '../core/init.php';
require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';


    	$hashed = $super_data['super_password'];
       $old_password = ((isset($_POST['old_password']))?sanitize($_POST['old_password']):'');
       $old_password = trim($old_password);
       $super_password = ((isset($_POST['super_password']))?sanitize($_POST['super_password']):'');
       $super_password = trim($super_password);
       $confirm = ((isset($_POST['confirm']))?sanitize($_POST['confirm']):'');
       $confirm = trim($confirm);
       $new_hashed = password_hash($super_password, PASSWORD_DEFAULT);
       $super_id = $super_data['super_id'];
       $errors = array();
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      	<?php
 			if ($_POST) {
 				//form validetion
 				if (empty($_POST['old_password']) || empty($_POST['super_password']) || empty($_POST['confirm'])) {
 					$errors[] = 'You must provide value for all fields';
 				}
          // if new password matches Confirm
          if ($super_password != $confirm) {
            $errors[] = 'The New Password does not match Confirm password!';
          }
 					//password is more than 6 charaters
 					if (strlen($super_password )< 11) {
 						$errors[] = 'Password must be atleast 11 characters';
 					}


 			if(!password_verify($old_password, $hashed)) {
 					$errors[] = 'old Password does not match our record';
 				}

 				//check for errors
 			if (!empty($errors)) {
 				echo display_errors($errors);
 			}else{
 				// change password
        $db->query("UPDATE superuser SET super_password = '$new_hashed' WHERE super_id = '$super_id'");
        $_SESSION['success_flash'] = 'Your password has been updated!';
        header('Location:dashboard.php');

 			}
 			}
 			?>

 		<h2 class="text-center">Change Password</h2>
 		<form action="change_password.php" method="post">
 			<div class="form-group">
 				<label class="text-dark" for="old_password">Old_password:*</label>
 				<input type="password" name="old_password" id="old_password" value="<?=$old_password;?>" class="form-control">
 			</div>
 			<div class="form-group">
 				<label class="text-dark" for="password"> New Password:*</label>
 				<input type="super_password" name="super_password" id="password"
 				value="<?=$super_password;?>" class="form-control" >
 			</div>
      <div class="form-group">
 				<label class="text-dark" for="confirm">Confirm New Password:*</label>
 				<input type="password" name="confirm" id="confirm"
 				value="<?=$confirm;?>" class="form-control" >
 			</div>
 			<div class="form-group">
        <a href="dashboard.php" class = "btn btn-danger">Cancel</a>
 				<input type="submit" value="Change Password" class="btn btn-primary">
 			</div>
 		</form>

      </div>

    </div>

  </div>

    <?php
    include 'includes/footer.php';

?>