<?php 
  require_once '../core/init.php';
require_once '../helpers/helpers.php';

$parentID = (int)$_POST['parentID'];
$selected = sanitize($_POST['selected']);
$childQuery = $db->query("SELECT * FROM book_categories WHERE book_parent = '$parentID' ORDER BY category ");
ob_start(); ?>
	<option value=""></option>
	<?php while($child = mysqli_fetch_assoc($childQuery)): ?>
	<option value="<?=$child['cat_id'];?>" <?=(($selected == $child['cat_id'])?'selected':'');?>><?=$child['category'];?></option>
	<?php endwhile; ?>
<?php echo ob_get_clean(); ?>