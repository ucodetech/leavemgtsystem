<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

?>
          <div class="content-wrapper">
            <div class="content">
                <div class="container-fluid">
              

    	<?php 

		$sql = "SELECT * FROM `correctRequest` WHERE deleted = 0 ";
		$query = $db->query($sql);
    	 ?>
    <div class="table-responsive">
    	<h3 class="text-primary text-center">Student Emails</h3>
        <table id="stuEmails" class="table table-hover table-striped">
            <thead>
                <th>ID</th>
                <th>Name</th>
                <th>MatricNo</th>
                <th>Email</th>
                <th>Problem</th>
                <th>Date requested</th>
                <th>Done</th>
               
            </thead>
            <tbody>
            	<?php while ($row = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?=$row['id'];?></td>
                    <td><?=$row['student_full_name'];?></td>
                    <td><?=$row['student_matric_no'];?></td>
                    <td><?=$row['student_email_address'];?></td>
                    <td><?=$row['problem'];?></td>
                    <td><?=$row['DateRequested'];?></td>
                    <td>
                <?php  if($row['deleted'] == 0): ?>
                    <span class="text-danger">No</span>
                <?php else: ?>
                <span class="text-success">Yes</span>
                <?php endif; ?>
            </td>

                </tr>
               <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>
           
<?php
    include 'includes/footer.php';

?>