<?php

require_once '../core/init.php';
  	require_once '../helpers/helpers.php';
  	
  	if(isset($_GET['id'])){
  	    $id = (int)$_GET['id'];
  	    $id = sanitize($id);
  	    $status = 0 ;
  	    $sql = "INSERT INTO superprofile (super_id, status) VALUES ('$id', '$status') ";
  	    $query = $db->query($sql);
  	    
  	    if($query){
  	        $_SESSION['success_flash'] = 'Profile Created!';
  	        header("Location: dashboard.php");
  	    }else{
  	        echo 'something went wrong '. mysqli_error($db);
  	    }
  	}