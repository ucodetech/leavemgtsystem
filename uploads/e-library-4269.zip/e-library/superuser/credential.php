<?php 
	
	define('EMAIL', 'info@e-library.uzbgraphix.com.ng');
	define('PASS', 'echomike12@#');
?>