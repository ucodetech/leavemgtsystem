<?php
	  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

?>    
          <meta http-equiv="refresh" content="60">

  <?php 
      $sql = "SELECT * FROM `book_categories` WHERE book_parent = 0 ";
      $pquery = $db->query($sql);
      $count = mysqli_num_rows($pquery );

      $sqlcount = "SELECT * FROM `books` WHERE book_deleted = 0 ";
      $pcount = $db->query($sqlcount);
      $count = mysqli_num_rows($pcount);

      $sqls = "SELECT * FROM students";
      $query = $db->query($sqls);
        $totReg = mysqli_num_rows($query);

   ?>
    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <div class="content-header">
        <?php 
         $userQuery =$db->query("SELECT * FROM superuser WHERE super_id = '$super_admin_id' ");
        $sperft = mysqli_fetch_assoc($userQuery);
        $superid = $sperft['super_id'];
        
         $sqlim = "SELECT * FROM superprofile WHERE super_id = '$superid' ";
        $queryim = $db->query($sqlim);
        $rowimg = mysqli_fetch_assoc($queryim);
        
            if(empty($rowimg)){
                    ?>
                    <a href="createprofile.php?id=<?=$superid['super_id'];?>">Create Profile</a>
                    <?
                }

        ?>
 <div class="container-fluid">
    
        <div class="table-responsive" id="student_login_activity">
    	               
        </div>
        
         <div class="table-responsive" id="admin_login_activity">
    	               
        </div>

    </div><hr>
      <div class="container">
    
      <div class="row">

        <div class="col-md-4 bg-danger">
          <p class="text-center" style="padding: 10px 10px; font-size: 50px;"> 
            <small style="font-size: 20px;">Students <br>  </small>(<?=$totReg;?>)
          </p>
        </div>
        <div class="col-md-4 bg-primary">
            <p class="text-center" style="padding: 10px 10px; font-size: 50px;"> 
              <small style="font-size: 20px;">
              Total Books In the Library </small>(<?=$count;?>)
          </p>       

        </div>
        <div class="col-md-4 bg-info">
          <?php
          //new visitorsip
            $visitor_ip = $_SERVER['REMOTE_ADDR'];
            //checking if visitors is unique
            $ipSql = "SELECT * FROM userip WHERE ip_address = '$visitor_ip' ";
            $ipresult = $db->query($ipSql);
            if (!$ipresult) {
              echo "Error Retrieving the ip";
            }
            $total_visitors = mysqli_num_rows($ipresult);
            if ($total_visitors < 1) {
              $ipSql = "INSERT INTO userip (ip_address) VALUES ('$visitor_ip') ";
              $ipresult = $db->query($ipSql);
            }
        // retrieving visitorsip from database
        $ipSql = "SELECT * FROM userip ORDER BY id ";
        $ipresult = $db->query($ipSql);
        if (!$ipresult) {
          echo "Error Retrieving the ip";
        }
        $total_visitors = mysqli_num_rows($ipresult);
   ?> 
      <p class="text-center" style="padding: 10px 10px; font-size: 50px;"> 
              <small style="font-size: 20px;">
              Users</small> <br>(<?=$total_visitors;?>)
          </p> 
        </div>

      </div>

    </div><hr>

      <div class="container-fluid">
        <?php include 'filters.php' ?>
      </div><!-- /.container-fluid -->
       
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <h2 class="text-center text-info">All books By Category</h2><hr>
            <div class="row">
               <div class="col-md-8">
                 <div class="row">
          <?php while ($parent = mysqli_fetch_assoc($pquery)): ?>
            <?php 
            $parent_id = $parent['cat_id'];
            $sql2 = "SELECT * FROM `book_categories` WHERE book_parent = '$parent_id' ";
            $cquery = $db->query($sql2)
             ?>
           <div class="col-md-3">
            <div class="dropdown">
              <span><?=$parent['category'];?></span> <br>
              <i class="dropdown-toggle fa fa-folder-open fo" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></i>
  
            <div class="dropdown-menu" style="background-color: none;" aria-labelledby="dropdownMenuButton">
              <?php while($child = mysqli_fetch_assoc($cquery)): ?>
              <a class="dropdown-item" href="all_book.php?cat=<?=$child['cat_id'];?> "><i class="fa fa-file"></i><br><span class="na"><?=$child['category'];?></span></a>
             <?php endwhile; ?>
             
            </div>
          </div>
            </div>
             <?php endwhile; ?>
              </div>
            </div>
            <div class="col-md-4 bf">
                  <?php include 'all_refere.php'; ?>
            </div>
          </div>
                      

    </div><!-- /.container-fluid -->
    
  </div><!-- /.content -->
 

 
  
</div> <!-- /.content-wrapper -->
           
           
           
<?php include 'includes/footer.php';?>
<script>
 $('document').ready(function(){
    	        update_admin_login();
    	       
    			function update_admin_login()
    			{
    			    var action = 'update_time_admin';
    			    $.ajax({
    			       url:"updateAction.php",
    			       method:"POST",
    			       data:{action:action},
    			       success:function(data)
    			       {
    			        
    			         
    			       },
    			       error:function(){alert("something went wrong")}
    			      
    			    });
    			}
    			 setInterval(function(){
    			   update_admin_login(); 
    			}, 3000);
    			
    		
    });
    
    
     $('document').ready(function(){
    	        fetch_student_login();
    	       
    	        setInterval(function(){
    			   fetch_student_login(); 
    			}, 3000);
    			
    			function fetch_student_login()
    			{
    			    var action = 'fetch_data';
    			    $.ajax({
    			       url:"action.php",
    			       method:"POST",
    			       data:{action:action},
    			       success:function(data)
    			       {
    			         $('#student_login_activity').html(data);
    			         
    			       },
    			       error:function(){alert("something went wrong")}
    			      
    			    });
    			}
    			
    		
    });
    
     $('document').ready(function(){
    	        fetch_admin_login();
    	       
    	        setInterval(function(){
    			   fetch_admin_login(); 
    			}, 3000);
    			
    			function fetch_admin_login()
    			{
    			    var action = 'admin_data';
    			    $.ajax({
    			       url:"actions.php",
    			       method:"POST",
    			       data:{action:action},
    			       success:function(data)
    			       {
    			         $('#admin_login_activity').html(data);
    			         
    			       },
    			       error:function(){alert("something went wrong")}
    			      
    			    });
    			}
    			
    		
    });
    
    
</script>

<style type="text/css">
  .fa-folder-open{
    font-size: 80px;
    color: #825503db;
  }
  .fa-file{
    font-size: 50px;
    color: #822c03;
  }
  .na{
    font-size: 18px;
    font-family: Poppins;
    color: #822c03;

  }
  .bf{
    border-left: 2px solid grey;
    overflow: scroll;
  }
</style>