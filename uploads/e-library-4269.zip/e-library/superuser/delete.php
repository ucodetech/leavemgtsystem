<?php
  require_once '../core/init.php';
 require_once '../helpers/helpers.php';	
		 
    if (isset($_GET['delete'])) {
      $deleteid = (int)$_GET['delete'];
      $deleteid = sanitize($deleteid);
      $sql = "DELETE FROM messages WHERE id = '$deleteid' ";
      $result = $db->query($sql);

      if ($result) {
      	$_SESSION['success_flash'] = 'Deleted!';
      	  header("Location: send_notification.php");
      }else{
      	echo 'error ' .mysqli_error($db);
      }
    

    }

