<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

?>
   
   
 		<style type="text/css">
    label{
      color: #fff !important;
      font-family:Poppins !important;
      font-weight: bolder;
    }
    .card-header{
      font-size: 20px !important;
      font-family:Poppins !important;
    }
   </style>
    <div class="content-wrapper">
            <div class="content">
                <div class="container">
  <div class="jumbotron text-center" style="margin-bottom: 0; padding: 1rem 1rem;">
    <img src="../images/logo.png" class="img-fluid" width="300" alt="LMS Logo">
    
  </div>
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        
      </div>
      <div class="col-md-6" style="margin-top: 20px;">
        <div class="card bg-dark">
          <div class="card-header text-center">
            <i class="fa fa-plus"></i> Add Librarain
          </div>
          <div class="card-body text-light">

 				<?php 
 			//delete function
 if (isset($_GET['delete'])){
  $id = sanitize($_GET['delete']);
    $db->query("DELETE FROM `librarian` WHERE lib_id = '$id' ");
    if (!headers_sent()) {
        header("Location: librarains.php");
          exit;
      }
    
}

           if (isset($_GET['edit'])) {
		     $edit_id = (int)$_GET['edit'];
		       $libQuery = $db->query("SELECT * FROM `librarian` WHERE lib_id = '$edit_id' ");
            $alibquery = mysqli_fetch_assoc($libQuery);

		    $lib_full_name = ((isset($_POST['lib_full_name']) && !empty($_POST['lib_full_name']))?sanitize($_POST['lib_full_name']): $alibquery['lib_full_name']);
		    $lib_email_address = ((isset($_POST['lib_email_address']) && !empty($_POST['lib_email_address']))?sanitize($_POST['lib_email_address']): $alibquery['lib_email_address']);
		    $lib_phone_no = ((isset($_POST['lib_phone_no']) && !empty($_POST['lib_phone_no']))?sanitize($_POST['lib_phone_no']): $alibquery['lib_phone_no']);
		    
		    }

        if ($_POST) {
        	$errors = array();
          $required = array('lib_full_name', 'lib_email_address', 'lib_phone_no');
          foreach ($required as $f) {
            if(empty($_POST[$f])){
     
             $errors[] = 'All field are required!';
            }
          }
            if (!filter_var($lib_email_address, FILTER_VALIDATE_EMAIL) ) {
              $errors[] = 'Invalid lib_email_address!';
            }


          if (!empty($errors)) {
            echo display_errors($errors);
          }else{
            //add user to database
             if (isset($_GET['edit'])) {

            $sql = "UPDATE librarian SET lib_full_name = '$lib_full_name', lib_phone_no = '$lib_phone_no', lib_email_address = '$lib_email_address' WHERE lib_id = '$edit_id' )";
            $result = $db->query($sql);
            // $stmt = mysqli_stmt_init($db);
            // if (!mysqli_stmt_prepare($stmt, $sql)) {
            // 	$errors[] = 'SQL Error';
            // }else{
            // 	mysqli_stmt_bind_param($stmt, "sss", $lib_full_name,$lib_phone_no, $lib_email_address );
            // 	$result = mysqli_stmt_execute($stmt)

            // }
            if ($result) {
            	$_SESSION['success_flash'] = 'successfully!';
              	  if (!headers_sent()) {
                  header("Location: librarains.php");
                    exit;
      }
    
            }else{
            	echo 'Errors ' .mysqli_error($db);
            }
              
          }
           
        }
    }

      ?>


 				 
 				<form method="POST" action="edit.php?<?=((isset($_GET['edit']))?'edit='.$edit_id : '');?>"> 				
 						<div class="col-md-12 form-group">
 							<label>Librarain Full Name: <span class="text-danger">*</span></label>
 							<input type="text" name="lib_full_name" value="<?=$lib_full_name;?>"  class="form-control">
 						</div>
 						<div class="col-md-12 form-group">
 							<label>Librarain email address: <span class="text-danger">*</span></label>
 							<input type="email" name="lib_email_address" value="<?=$lib_email_address;?>"  class="form-control">
 						</div>
 						<div class="col-md-12 form-group">
 							<label>Librarain Phone Number <span class="text-danger">*</span></label>
 							<input type="number" name="lib_phone_no"  value="<?=$lib_phone_no;?>" class="form-control">
 						</div>
 						<div class="col-md-12 form-group">
 							<a href="dashboard.php" class="alert alert-danger">Cancel</a>
 							<input type="submit" class="btn btn-info btn-fill pull-right up" value="<?=((isset($_GET['edit']))?'Update ':'');?> Details">
 						</div>
 					
 				</form>
 			
          </div>
        </div>
        
      </div>
      
    </div>

  </div>


                </div>
            </div>
          </div>
      <?php include 'includes/footer1.php'; ?>
