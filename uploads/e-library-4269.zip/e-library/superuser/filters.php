 
  <?php

  $cat_id = ((isset($_REQUEST['cat']))?sanitize($_REQUEST['cat']): '');
  $book_title = ((isset($_REQUEST['book_title']))?sanitize($_REQUEST['book_title']): '');
  $book_author =((isset($_REQUEST['book_author']))?sanitize($_REQUEST['book_author']):'');
  $book_publication_date =((isset($_REQUEST['book_publication_date']))?sanitize($_REQUEST['book_publication_date']):'');
  $book_edition =((isset($_REQUEST['book_edition']))?sanitize($_REQUEST['book_edition']):'');


 $editionQuery = $db->query("SELECT * FROM books ORDER BY book_edition");
 $pubQuery = $db->query("SELECT * FROM books ORDER BY book_publication_date");

   ?>

<div class="container-fluid" id="search">

  <h3 class="text-center">Search Book </h3>
    <form  action="search.php" method="post">
   <div class="row">
        <div class="form-group col-md-4">
              <label>Filter By Book Title</label>
            <input type="hidden" name="cat" value="<?=$cat_id;?>">
              <input type="text" name="book_title" class="form-control">
         </div>
       <div class="form-group col-md-4">
              <label>Filter By Author's name</label>
              <input type="text" name="book_author" class="form-control">
         </div>

       
	<div class="col-md-4 form-group">
	<label>Filter By Book Date Publication</label>
	<select name="book_publication_date" id="book_publication_date" class="form-control">
	<option value=""></option>
	<?php while($b_pub = mysqli_fetch_assoc($pubQuery)): ?>
	<option value="<?=$b_pub['book_publication_date'];?>"><?=$b_pub['book_publication_date'];?></option>
		<?php endwhile ?>
	</select>
    </div>
   <div class="col-md-4 form-group">
	<label>Filter By Book Edition</label>
	<select name="book_edition" id="book_edition" class="form-control">
	<option value=""></option>
	<?php while($b_edition = mysqli_fetch_assoc($editionQuery)): ?>
	<option value="<?=$b_edition['book_edition'];?>"><?=$b_edition['book_edition'];?></option>
		<?php endwhile ?>
	</select>
    </div>
    
     <div class="form-group col-md-3 mt-4">
       <input type="submit" name="" value="Search" class="btn  btn-success bt">
     </div>
	</div>
	</form>
	
</div>

	<style type="text/css">
		.bt{
			background-color: blue !important;
			border:4px solid #fff !important;
			color: #fff;
			border-radius: 60px;
		}
		.bt:hover{
			color: #fff;
			background-color: orangered !important;
		}

	</style>