<?php 

  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
//grant request
    if (isset($_GET['grants'])) {
    	$grantid = (int)$_GET['grants'];
    	$grantid = sanitize($grantid);
    	$granted = 1;
    	$updategrant = "UPDATE `reference_book_grant` SET book_grant = '$granted' WHERE id = '$grantid' ";
    	$grantquery = $db->query($updategrant);
    	
    	$studentred = $db->query("SELECT * FROM `reference_book_grant` WHERE id = '$grantid' ");
    	$studentget = mysqli_fetch_assoc($studentred);
    	$bookid = $studentget['book_id'];
    	$studentid = $studentget['stud_id'];
    	
    	$sql = "SELECT *  FROM `reference_books` WHERE book_id = '$bookid' ";
        $query = $db->query($sql);
        $book = mysqli_fetch_assoc($query);
        $booktitle = $book['book_title'];
    	
    	$studentredd = $db->query("SELECT * FROM students WHERE student_id = '$studentid' ");
    	$studentgett = mysqli_fetch_assoc($studentredd);
    	
    	$studentemail = $studentgett['student_email_address'];

    	if ($grantquery) {
    	    
    	    
              	require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/PHPMailer.php");
                require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/Exception.php");
                require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/SMTP.php");

                $mail =  new PHPMailer\PHPMailer\PHPMailer();
                //SMTP settings
                $mail->isSMTP();
                $mail->Host = "smtp.gmail.com";
                $mail->SMTPAuth = true;
                $mail->Username = "ucodetech.wordpress@gmail.com";
                $mail->Password =  "echo@mike12@@";
                $mail->Port = 587; //587 for tls
                $mail->SMTPSecure = "tls";
                
                //email settings
                $mail->isHTML(true);
                $mail->setFrom("ucodetech.wordpress@gmail.com");
                $mail->addAddress($studentemail);
                $mail->addReplyTo("ucodetech.wordpress@gmail.com");
                $mail->Subject = "e-Library Request Granted";
                $mail->Body = "<div style='width: 80%; height: auto; border:2px solid #000; color:black; font-family: Poppins;'>
   
 <p align='center'><img src='https://e-library.uzbgraphix.com.ng/images/hg.png' class='img-fluid' width='300' alt='LMS Logo' align='center'>  </p>          
 <p style='background: #000;color: #fff; font-size: 20px; text-align: center; text-transform: uppercase;margin-top:0px'>Request Granted</p> 
         <p  style='color: #000; font-size: 18px; text-transform:capitalize;margin:10px;  '>
        Your request to have access to Reference Book with title <span style='color:green;'>$booktitle</span>  have been granted! now login to your portal to access the book <br>
         <a  href='https://e-library.uzbgraphix.com.ng/studentsportal/login.php'>Login</a>

 
  <p style='background: #000;color: #fff; font-size:20px; text-align: center; text-transform: uppercase;'> 
  <a href='http//e-library.uzbgraphix.com.ng' style='color:#fff;'>Offical Site</a></p>
             
</div>";
        if($mail->send()){
            	$_SESSION['success_flash'] = 'Request Granted! An email will be sent to the student';
    		header("Location: student_request.php");
        }else{
            echo 'Error Occured ' .$mail->ErrorInfo();
        }
             
    	    
    	
    	}else{
    		echo "There was an error ".mysqli_error($db);
    	}
    }

//cancel request
    if (isset($_GET['cancel'])) {
    	$cancelid = (int)$_GET['cancel'];
    	$cancelid = sanitize($cancelid);
    	$canceled = 0;
    	$updatecancel = "UPDATE `reference_book_grant` SET book_grant = '$canceled ' WHERE id = '$cancelid' ";

    	$cancelquery = $db->query($updatecancel);

    	if ($cancelquery) {
    		$_SESSION['success_flash'] = 'Request canceled!';
    		header("Location: student_request.php");
    	}else{
    		echo "There was an error ".mysqli_error($db);
    	}
    }