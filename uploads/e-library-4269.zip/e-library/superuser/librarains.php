<?php
	require_once '../core/init.php';
  	require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

   
$userQuery =$db->query("SELECT * FROM librarian ORDER BY lib_full_name");
 ?>
 <div class="content-wrapper">
 <div class="content">
 <h2 class="text-primary  text-center" >Librarians</h2>
 <a href="add_librarians.php?add=1" class="btn btn-success pull-right " id="add-product-btn">Add New librarian</a>
 <hr>
 <div class="table-responsive">
 	<table id="librarains" class="table table-stripped table-bordered table-condensed">
   <thead>
     <th>control</th>
     <th>Name</th>
     <th>Email</th>
     <th>Date Added</th>
     <th>Last Login</th>
     <th>Permissions</th>
   </thead>
   <tbody>

     <?php
       if (mysqli_num_rows($userQuery) > 0) {
    while ($user = mysqli_fetch_assoc($userQuery)) {
      ?>
      <tr>
       <td>
        <a href="edit.php?edit=<?=$user['lib_id']; ?>" class="btn btn-success btn-xs"><span class="fa fa-edit"></span></a>
         <a href="edit.php?delete=<?=$user['lib_id']; ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span></a>
       </td>
       <td><?=$user['lib_full_name'];?></td>
       <td><?=$user['lib_email_address'];?></td>
       <td><?=(($user['lib_date_enrolled'] == '0000-00-00 00:00:00')?'Never ':pretty_date($user['lib_date_enrolled']));?></td>
       <td><?=(($user['lib_last_login'] == '0000-00-00 00:00:00')?'Never ':pretty_date($user['lib_last_login']));?></td>
       <td><?=$user['permissions_lib'];?></td>
     </tr>
      <?
    }
  }
 ?>
    
     
   </tbody>
 </table>
 </div>
</div>
</div>

<?php include 'includes/footer.php' ?>
