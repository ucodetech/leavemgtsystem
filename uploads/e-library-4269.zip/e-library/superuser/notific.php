<?php
     require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
    


		if ($_POST) {

    $title = ((isset($_POST['title']))?sanitize($_POST['title']): '');
    $student = ((isset($_POST['student']))?sanitize($_POST['student']): '');
    $msg= ((isset($_POST['msg']))?sanitize($_POST['msg']): '');

                  $no = 0;
                    $sql = "INSERT INTO messages
                     (student,	title,	msg, hasRead) VALUES
                     (?,?,?,?); ";
                    $stmt = mysqli_stmt_init($db);
                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                      $errors[] = 'SQL Error';
                    }else{
                    mysqli_stmt_bind_param($stmt, "ssss", $student, $title, $msg,  $no);
                    $result =  mysqli_stmt_execute($stmt);
                    
              }
                  
                  
                    if ($result) {
                      echo "Notification Sent to student!";
                    }else {
                    	echo "something went wrong!".mysqli_error($db);
                    }

										
                }
