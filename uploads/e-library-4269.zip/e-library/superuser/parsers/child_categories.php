<?php 
 require_once $_SERVER['DOCUMENT_ROOT']. '/eLibrary/core/init.php';

$parentID = (int)$_POST['parentID'];
$childQuery = $db->query("SELECT * FROM book_categories WHERE book_parent = '$parentID' ");
ob_start(); ?>
	<option value=""></option>
	<?php while($child = mysqli_fetch_assoc($childQuery)): ?>
	<option value="<?=$child['cat_id'];?>"><?=$child['category'];?></option>
	<?php endwhile; ?>
<?php echo ob_get_clean(); ?>