<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';


    $sql = "SELECT * FROM students ORDER BY student_id DESC ";
	$studentQuery = $db->query($sql);

?> 
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
      	<h5>Send Notification</h5>
      </div><!-- /.container-fluid -->
       
    </div><hr>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      	<form id="notifForm">
      <div class="row">
 		<div class="form-group col-md-6">
 		<label class="text-primary">Select student</label>
 		 <select name="student" id="student" class="form-control">
              <option value=""></option>
              <?php while($student = mysqli_fetch_assoc($studentQuery)): ?>
              <option value="<?=$student['student_id'];?>"><?=$student['student_matric_no'];?> </option>
                <?php endwhile ?>
            </select>
 		</div>
 		<div class="col-md-6 form-group">
 			<label class="text-primary">Message Title</label>
 			<input type="text" name="title" id="title" class="form-control">
 		</div>
 		<div class="col-md-6 form-group">
 			<label class="text-primary">Message</label>
 			<textarea name="msg" id="msg" class="form-control" rows="10">
 				
 			</textarea>
 		</div>
 		<div class="col-md-6  form-inline">
 			<input type="submit" name="submit" value="Send" class="btn btn-success">
 			 <span id="loader" style="display:none; margin-left: 10px;"> <img src="../preloader/ajax-loader.gif" alt="">
 		</div>
 		<span id="student-errors" class="text-danger"></span>
    	<span id="student-success" class="text-success"></span>

 	</div>
 		
      	</form>

      </div><hr>
      <div class="container-fluid">
      	<?php  
      	$notesql = "SELECT * FROM messages ORDER BY id DESC ";
         $notequery = $db->query($notesql);


          ?>

           <h4 class="text-center">Notifications Sent</h4>
           <div class="table-responsive">
           	<table class="table table-striped table-hover" id="note">
           		<thead>
           			<th>ID</th>
           			<th>Title</th>
           			<th>Message</th>
           			<th>Student</th>
           			<th>Matric No</th>
           			<th>Delete</th>
           		</thead>
           		<tbody>
           			<?php while ($rowgt = mysqli_fetch_assoc($notequery)) : 

           				$studentid = $rowgt['student'];
           				$studentsql = $db->query("SELECT * FROM students WHERE student_id = '$studentid' ");
           				$rowst = mysqli_fetch_assoc($studentsql);

           				?>
           			<tr>
           				<th><?=$rowgt['id'];?></th>
           				<td><?=$rowgt['title'];?></td>
           				 <td><?=$rowgt['msg'];?></td>
           				 <td><?=$rowst['student_full_name'];?></td>
           				  <td><?=$rowst['student_matric_no'];?></td>
           				  <td>
           				  	<?php if ($rowgt['hasRead'] == 1): ?>
           				  		<a href="delete.php?delete=<?=$rowgt['id'];?>" class="btn  btn-danger"><i class="fa fa-trash"></i>Notification read</a>
           				  		<?php else: ?>
           				  			<span class="text-info">Not Read Yet</span>
           				  	<?php endif ?>
           				  </td>

           			</tr>
           		<?php endwhile; ?>
           		</tbody>
           	</table>
           	
           </div>
      </div>
    </div>

  </div>

    <?php include 'includes/footer.php';?>
    <script type="text/javascript">
$(document).ready(function(){
	$('#notifForm').on('submit', function(event){
				event.preventDefault();
				if ($('#student').val() == '') {
					$('#student-errors').fadeIn().html('Student is Required!');
					setTimeout(function(){
						$('#student-errors').fadeOut('slow');
					}, 5000);	
					}
					else if ($('#title').val() == '') {
						$('#student-errors').fadeIn().html('Title is Required!');
						setTimeout(function(){
							$('#student-errors').fadeOut('slow');
						}, 5000);
				}
				else if ($('#msg').val() == '') {
						$('#student-errors').fadeIn().html('Message is Required!');
						setTimeout(function(){
							$('#student-errors').fadeOut('slow');
						}, 5000);
				}
				else{
					$('#student-errors').html('');
			$.ajax({
				url:"notific.php",
				method: "POST",
				data:$('#notifForm').serialize(),
				beforeSend: function(){
					$("#loader").show();
				},
					complete:function(){
							$("#loader").hide();
					},
				success:function(data){
					$("form").trigger("reset");
					$('#student-success').fadeIn().html(data);
					setTimeout(function(){
						$('#student-success').fadeOut('slow');
					}, 5000);
				},
				error: function(){alert('something went wrong')}
			});
		}
	});
});
    </script>