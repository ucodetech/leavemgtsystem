<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

?>
          <div class="content-wrapper">
            <div class="content">
                <div class="container-fluid">
                	  
    	<?php 

		$sql = "SELECT * FROM students ORDER BY student_id ";
		$query = $db->query($sql);
    	 ?>
    <div class="table-responsive">
    	<h3 class="text-primary text-center">Student Emails</h3>
        <table id="stuEmails" class="table table-hover table-striped">
            <thead>
                <th>ID</th>
                <th>Name</th>
                <th>Department</th>
                <th>Email</th>
                <th>Username</th>
                <th>Phone No</th>
                <th>Email Verified</th>
                <th>Permission</th>
            </thead>
            <tbody>
            	<?php while ($row = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?=$row['student_id'];?></td>
                    <td><?=$row['student_full_name'];?></td>
                    <td><?=$row['student_department'];?></td>
                    <td><?=$row['student_email_address'];?></td>
                    <td><?=$row['student_username'];?></td>
                    <td><?=$row['student_phone_no'];?></td>
                    <td>
                <?php  if($row['verified'] == 0): ?>
                    <span class="text-danger">No</span>
                <?php else: ?>
                <span class="text-success">Yes</span>
                <?php endif; ?>
            </td>
             <td><?=$row['permissions_stud'];?></td>

                </tr>
               <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</div>
</div>
           
<?php
    include 'includes/footer.php';

?>