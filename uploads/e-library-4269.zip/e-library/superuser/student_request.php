<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

    //this gets the book request table
     $sqlstudents = $db->query("SELECT * FROM students");
	$sttt = mysqli_fetch_assoc($sqlstudents);


    
     $sqlcheck = $db->query("SELECT * FROM `reference_book_grant`");
     $count = mysqli_num_rows($sqlcheck);




  ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
     
       <div class="container-fluid">
        <span class="text-danger">Total request (<?=$count;?>)</span>
        </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
      	<h4 class="text-center">Students who requested for Reference book</h4><hr>
      	<div class="table-responsive">
      		<table id="grantRequest" class="table table-striped table-hover">
      			<thead>
      				<th>Student Name</th>
      				<th>Department</th>
      				<th>Book Title</th>
      				<th>Grant</th>

      			</thead>
      			<tbody>
      				<?php 
      				while($fetched = mysqli_fetch_assoc($sqlcheck)):

				     //this gets the reqest id
				     $booktitle = $fetched['book_id'];
				     //this gets the student id
				     $studentid= $fetched['stud_id'];


				//this fetches the book title base on the book id
				    $sqltitle = $db->query("SELECT * FROM `reference_books` WHERE book_id = '$booktitle'");
				    $rq = mysqli_fetch_assoc($sqltitle);

				//this gets student name
				    $sqlstudent = $db->query("SELECT * FROM students WHERE student_id = '$studentid'");
				    $ra = mysqli_fetch_assoc($sqlstudent);



      				 ?>
      				<tr>
      					<td><?=$ra['student_full_name'];?></td>
      					<td><?=$ra['student_department'];?></td>
      					<td><?=$rq['book_title'];?></td>
      					<td>
      						<?php if ($fetched['book_grant'] == 0): ?>
      							<a class="btn btn-sm btn-success" href="grants.php?grants=<?=$fetched['id'];?>"><i class="fa fa-check">Grant Request</i></a>
      							<?php else: ?>
      						<span class="text-success">Granted</span>

      							<a class="btn btn-sm btn-warning" href="grants.php?cancel=<?=$fetched['id'];?>"><i class="fa fa-check">Cancel Grant</i></a>
      						<?php endif ?>
      					</td>
      				</tr>
      			<?php endwhile; ?>
      			</tbody>
      		</table>
      	</div>

      </div>

    </div>

  </div>

    <?php
    include 'includes/footer.php';

?>