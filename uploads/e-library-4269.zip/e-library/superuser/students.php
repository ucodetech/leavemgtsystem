<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

?>
    <div class="content-wrapper">
            <div class="content">
                <div class="container-fluid">
                	  
<?php 

		$sql = "SELECT * FROM students ORDER BY student_id DESC ";
		$query = $db->query($sql);
 ?>
<div class="table-responsive">
<h3 class="text-primary text-center">Students</h3>

<table  id="students" class="table table-hover table-striped">
    <thead>
     	<th>ID</th>
        <th>Name</th>
        <th>Matric No</th>
        <th>Date Enrolled</th>
        <th>Last Login</th>
        <th>Permission</th>
        <th>Level</th>
        <th>Control</th>
        <th>Email Verified</th>
        <th>Approve</th>
    </thead>
    <tbody>
    	<?php while ($row = mysqli_fetch_assoc($query)): ?>
        <tr>
            <td><?=$row['student_id'];?></td>
            <td><?=$row['student_full_name'];?></td>
            <td><?=$row['student_matric_no'];?></td>
            <td><?=pretty_date($row['student_date_enrolled']);?></td>
            <td><?=pretty_date($row['student_last_login']);?></td>
            <td><?=$row['permissions_stud'];?></td>
             <td><?=$row['student_level'];?></td>

            <td>
            	<a href="updateStudent.php?edit=<?=$row['student_id'];?>" class="btn btn-sm btn-success"><i class="fa fa-edit"></i></a>
            	<a href="updateStudent.php?delete=<?=$row['student_id'];?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
            </td>
            <td>
                <?php  if($row['verified'] == 0): ?>
                    <span class="text-danger">No</span>
                <?php else: ?>
                <span class="text-success">Yes</span>
                <?php endif; ?>
            </td>
            <td>
            <?php if ($row['permissions_stud'] == 'notapproved'): ?>
            <a href="approve.php?approve=<?=$row['student_id'];?>" class="btn btn-sm btn-warning">approve<i class="fa fa-check"></i></a>
            <?php else: ?>
					<a href="approve.php?deapprove=<?=$row['student_id'];?>" class="btn btn-sm btn-danger">cancel<i class="fa fa-close"></i></a>
            <?php endif ?>
            </td>
        </tr>
       <?php endwhile; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>

<?php
    include 'includes/footer.php';

?>