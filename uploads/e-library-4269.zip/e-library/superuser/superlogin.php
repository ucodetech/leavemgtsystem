<?php 
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  include 'includes/head.php';



 ?>
 
   <style type="text/css">
    label{
      color: #fff !important;
      font-family:Poppins !important;
      font-weight: bolder;
    }
    .card-header{
      font-size: 20px !important;
      font-family:Poppins !important;
    }
   </style>
            <div class="content">
                <div class="container">
  <div class="jumbotron text-center" style="margin-bottom: 0; padding: 1rem 1rem;">
    <img src="../images/hg.png" class="img-fluid" width="300" alt="LMS Logo">
    
  </div>
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        
      </div>
      <div class="col-md-6" style="margin-top: 20px;">
        <div class="card bg-dark">
          <div class="card-header text-center">
            <i class="fa fa-user"></i> Super Login
          </div>
          <div class="card-body">
    <?php
      if ($_POST) {

        $super_email = mysqli_real_escape_string($db, $_POST['super_email']);
        $super_password = mysqli_real_escape_string($db, $_POST['super_password']);
        $errors = array();
        //form validetion
        if (empty($_POST['super_email']) || empty($_POST['super_password'])) {

          $errors[] = 'You must provide super_email and super_password';
        }
        
          //super_password is more than 6 charaters
          if (strlen($super_password )< 11) {
            $errors[] = 'super_password must be atleast 6 characters';
          }


        //check if email exit in the database

        
        $query = $db->query("SELECT * FROM superuser WHERE super_email = '$super_email'");
        $users = mysqli_fetch_assoc($query);
        $usersCount = mysqli_num_rows($query);
        if ($usersCount < 1) {
          $errors[] = 'You do not exit in the database';
         }
      if(!password_verify($super_password, $users['super_password'])) {
          $errors[] = 'Wrong super_password! Retype';
        }

        //check for errors
      if (!empty($errors)) {
        echo display_errors($errors);
      }else{
        // login visitor in
        $super_admin_id = $users['super_id'];
        super_login($super_admin_id);

      }
      }
      ?>
  <form method="POST" action="superlogin.php">
    
   
    <div class="form-group">
      <label>super_email:<span class="text-danger">*</span></label>
      <input type="text" name="super_email"  class="form-control">
    </div>
    <div class="form-group">
      <label>super_password:<span class="text-danger">*</span></label>
      <input type="password" name="super_password" class="form-control">
    </div>
    <div class="form-group">
    <button type="submit" name="login" class="btn btn-success">Super Login</button>
    </div>
    
 
  </form>
  
         
          </div>
        </div>
        
      </div>
      
    </div>

  </div>


                </div>
            </div>
<?php include 'includes/footer1.php'; ?>
<script type="text/javascript">

</script>