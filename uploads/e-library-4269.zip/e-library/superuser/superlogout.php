<?php
  include 'includes/head.php';
 header('Location: supersure.php');
 

 ?>