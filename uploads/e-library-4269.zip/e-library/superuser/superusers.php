<?php
	require_once '../core/init.php';
  	require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';
    include 'includes/nav.php';

   
$userQuery =$db->query("SELECT * FROM superuser");
 ?>
 <div class="content-wrapper">
 <div class="content">
 <h2 class="text-primary  text-center" >Superusers</h2>
 <a href="add_admin.php?add=1" class="btn btn-success pull-right " id="add-product-btn">Add New super user</a>
 <hr>
 <div class="table-responsive">
 	<table id="super" class="table table-stripped table-bordered table-condensed">
   <thead>
     <th>control</th>
     <th>Name</th>
     <th>Email</th>
     <th>Date Added</th>
     <th>Last Login</th>
     <th>Permissions</th>
   </thead>
   <tbody>

     <?php
       if (mysqli_num_rows($userQuery) > 0) {
    while ($user = mysqli_fetch_assoc($userQuery)) {
      ?>
      <tr>
       <td>
        <a href="edit.php?edit=<?=$user['super_id']; ?>" class="btn btn-success btn-xs"><span class="fa fa-edit"></span></a>
         <a href="edit.php?delete=<?=$user['super_id']; ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span></a>
       </td>
       <td><?=$user['super_full_name'];?></td>
       <td><?=$user['super_email'];?></td>
       <td><?=(($user['super_date_enrolled'] == '0000-00-00 00:00:00')?'Never ':pretty_date($user['super_date_enrolled']));?></td>
       <td><?=(($user['super_last_login'] == '0000-00-00 00:00:00')?'Never ':pretty_date($user['super_last_login']));?></td>
       <td><?=$user['permissions'];?></td>
     </tr>
      <?
    }
  }
 ?>
    
     
   </tbody>
 </table>
 </div>
</div>
</div>

<?php include 'includes/footer.php' ?>
