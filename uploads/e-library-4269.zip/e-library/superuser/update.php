<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
    if (!super_is_logged_in()) {
      super_login_error_redirect();
    }
    if (!has_permission_super('superuser')) {
      super_permission_error_redirect();
    }
    include 'includes/head.php';
    include 'includes/nav.php';



$parentQuery = $db->query("SELECT * FROM books WHERE hasCover = 0 ORDER BY book_id");

$book = ((isset($_POST['book']) && $_POST['book'] != '')?sanitize($_POST['book']): '');
 	if ($_POST) {
   $errors = array();
   if (empty($_POST['book'])) {
 			$errors[] = 'The book to update its cover is required!';
 		}
        
     if (!empty($_FILES)) {
      $file =$_FILES['book_cover'];
      $name = $file['name'];
      $nameArray = explode('.', $name);
      $fileName = $nameArray[0];
      $fileExt = $nameArray[1];
      $fileType = $file['type'];
      $tmpLoc = $file['tmp_name'];
      $fileSize = $file['size'];
      $fileError = $file['error'];
      $allowed  = array('jpg', 'jpeg', 'png' );
      $uploadName = 'b_'.$book.$fileName.".".$fileExt;
      $uploadPath ='../bookcovers/'.$uploadName;
      $dbpath = $uploadName;
  
      if (!in_array($fileExt, $allowed )) {
         $errors[] ='The file extension not supported!';
      }
      if ($fileSize > 1500000) {
         $errors[] ='The file size must be blow 15MB.';

      }
      if ($fileError != 0) {
      	 $errors[] ='Please Select an image!';
      }
    
    }
    if (!empty($errors)) {
      echo display_errors($errors);
    }else{
      //Upload file and Insert into database
      if (!empty($_FILES)) {
         move_uploaded_file($tmpLoc, $uploadPath);
      }
        $has = 1;
       $sql = "INSERT book_cover (book_id, cover, hasCover) VALUES (?,?,?) ";
                    $stmt = mysqli_stmt_init($db);
                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                      $errors[] = 'SQL Error';
                    }else{
                    mysqli_stmt_bind_param($stmt, "sss", $book, $dbpath, $has);
                    $result =  mysqli_stmt_execute($stmt);
               $result = $db->query("UPDATE books SET hasCover = 1 WHERE book_id = '$book' ");
                    
              }
           if ($result) {
              $_SESSION['success_flash'] = "Updated";
              header("Location: books.php");
            }else {
              echo "something went wrong!".mysqli_error($db);
            }
    }
  }




 ?>
 <div class="content-wrapper">
 <div class="content">
 	<hr>
 	<div class="container">
 		<h2 class="text-center text-primary">Add Cover</h2><hr>
 	<form method="post" action="update.php" enctype="multipart/form-data">
 <div class="row">
 	<div class="form-group col-md-6">
 		<label class="text-primary">Select Book To add Cover</label>
 		 <select name="book" id="book" class="form-control">
              <option value=""></option>
              <?php while($b = mysqli_fetch_assoc($parentQuery)): ?>
              <option value="<?=$b['book_id'];?>"><?=$b['book_title'];?></option>
                <?php endwhile ?>
            </select>
 	</div>
 	<div class="form-group col-md-6">
 		<label class="text-primary">Book Cover</label>
 		<input type="file" name="book_cover" class="form-control" >
 	</div>
 	<div class="form-group col-md-6">
 		<a href="books.php" class="btn btn-danger">Cancel</a>
 		<input type="submit" name="submit" value="Add Cover" class="btn btn-success" >
 	</div>
 	</div>
 </form>
 </div>
</div>
</div>

<?php include 'includes/footer.php' ?>