<?php
require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
		 
	 
    if($_POST['action']){
	   if($_POST['action'] == "update_time_admin"){
	       
	   $sql = "UPDATE superuser SET super_last_login = now()  WHERE super_id = ' $super_admin_id'";
	   $query = $db->query($sql);
	  
	  
	       
	   }
    }