<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';
  	if (!super_is_logged_in()) {
  		super_login_error_redirect();
  	}
  	if (!has_permission_super('superuser')) {
  		super_permission_error_redirect();
  	}
    include 'includes/head.php';

 
	//delete function
 if (isset($_GET['delete'])){
     $id = (int)$_GET['delete'];
  $id = sanitize($_GET['delete']);
   $result = $db->query("DELETE FROM students WHERE student_id = '$id' ");
    if($result){
    $_SESSION['success_flash'] = 'Deleted';
    header("Location: students.php");
    }   
}
		//edit function
     

?>
<style type="text/css">
   	label{
   		color: #fff !important;
   		font-family:Poppins !important;
   		font-weight: bolder;
   	}
   	.card-header{
   		font-size: 20px !important;
   		font-family:Poppins !important;
   	}
   </style>

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
       
      </div><!-- /.container-fluid -->
       
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container">

<div class="card bg-dark">
    <?php
        if (isset($_GET['edit'])) {
      $edit_id = (int)$_GET['edit'];
      $sqledit = "SELECT * FROM students WHERE student_id = '$edit_id' ";
      $query = $db->query($sqledit);
      $stu = mysqli_fetch_assoc($query);
      
    $student_full_name = strtoupper(((isset($_POST['student_full_name']) && $_POST['student_full_name'] != '')?sanitize($_POST['student_full_name']): $stu['student_full_name'])); 
    $student_phone_no = ((isset($_POST['student_phone_no']) && $_POST['student_phone_no'] != '')?sanitize($_POST['student_phone_no']): $stu['student_phone_no']);
    $student_matric_no = strtoupper(((isset($_POST['student_matric_no']) && $_POST['student_matric_no'] != '')?sanitize($_POST['student_matric_no']): $stu['student_matric_no']));
    $student_department = ((isset($_POST['student_department']) && $_POST['student_department'] != '')?sanitize($_POST['student_department']): $stu['student_department']);
    $student_email_address = ((isset($_POST['student_email_address']) && $_POST['student_email_address'] != '')?sanitize($_POST['student_email_address']): $stu['student_email_address']);
    $student_username = ((isset($_POST['student_username']) && $_POST['student_username'] != '')?sanitize($_POST['student_username']): $stu['student_username']); 
    $student_level = strtoupper(((isset($_POST['student_level']) && $_POST['student_level'] != '')?sanitize($_POST['student_level']): $stu['student_level'])); 

    if($_POST){
        $errors = array();
       
         if(empty($_POST['student_full_name'])){
            $errors[] = 'Full name can not be empty!';
        }
         if(empty($_POST['student_phone_no'])){
            $errors[] = 'Phone number can not be empty!';
        }
         if(empty($_POST['student_matric_no'])){
            $errors[] = 'Matric No. can not be empty!';
        }
         if(empty($_POST['student_department'])){
            $errors[] = 'Department can not be empty!';
        }
         if(empty($_POST['student_email_address'])){
            $errors[] = 'Email Address can not be empty!';
        }
         if(empty($_POST['student_username'])){
            $errors[] = 'Username can not be empty!';
        }
         if(empty($_POST['student_level'])){
            $errors[] = 'level can not be empty!';
        }
        
        if (!empty($errors)) {
                echo display_errors($errors);
            }else {
                if (isset($_GET['edit'])) {
                    $updateSql = "UPDATE students SET student_full_name = '$student_full_name', student_email_address = '$student_email_address', student_username = '$student_username',
                  student_phone_no  = '$student_phone_no' , student_matric_no = '$student_matric_no', student_department = '$student_department', student_level = '$student_level'    WHERE student_id = '$edit_id' ";
                 $updateResult = $db->query($updateSql);

                 
                }
 
                if ($updateResult) {
                 $updateSql2 = "UPDATE `correctRequest` SET deleted = 1, corrected = 'yes' WHERE student_email_address = '$student_email_address'";
                $db->query($updateSql2);
                    
                require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/PHPMailer.php");
                require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/Exception.php");
                require_once ("/home/uzbgraph/public_html/e-library/PHPMailer/SMTP.php");

                $mail =  new PHPMailer\PHPMailer\PHPMailer();
                //SMTP settings
                $mail->isSMTP();
                $mail->Host = "smtp.gmail.com";
                $mail->SMTPAuth = true;
                $mail->Username = "ucodetech.wordpress@gmail.com";
                $mail->Password =  "echo@mike12@@";
                $mail->Port = 587; //587 for tls
                $mail->SMTPSecure = "tls";
                
                //email settings
                $mail->isHTML(true);
                $mail->setFrom("ucodetech.wordpress@gmail.com");
                $mail->addAddress($student_email_address);
                $mail->addReplyTo("ucodetech.wordpress@gmail.com");
                $mail->Subject = "Correction Done";
                $mail->Body = "<div style='width: 80%; height: auto; border:2px solid #000; color:black; font-family: Poppins;'>
   
                 <p align='center'><img src='https://e-library.uzbgraphix.com.ng/images/hg.png' class='img-fluid' width='300' alt='LMS Logo' align='center'>  </p>          
                 <p style='background: #000;color: #fff; font-size: 20px; text-align: center; text-transform: uppercase;margin-top:0px'>Corrections</p>
                 
                         <p  style='color: #000; font-size: 18px; text-transform:capitalize;margin:10px;  '> Hi, $student_full_name <br>
                        You Requested to make corrections on your account. this is to alert you that the corrections have be made!<br>
                        Your Details
                        <ul>
                          <li>Full Name: $student_full_name</li>
                          <li>Email Address: $student_email_address</li>
                          <li>Matric No: $student_matric_no</li>
                          <li>Phone No: $student_phone_no</li>
                          <li>Username: $student_username</li>
                          <li>Department: $student_department</li>
                          <li>Level: $student_level </li>
                        </ul>
                        
                         <br> Have a nice day</p>
                                
                 
                  <p style='background: #000;color: #fff; font-size:20px; text-align: center; text-transform: uppercase;'> 
                  <a href='http//e-library.uzbgraphix.com.ng' style='color:#fff;'>Offical Site</a></p>
                             
                </div>";
                                 if($mail->send()){
                      $_SESSION['success_flash'] = 'Student Updated Successfully!';
                    header("Location: students.php");
                     
                 } else{
                 echo 'something went wrong ' .$mail->ErrorInfo;
 
                 }
              
              } else{
                	echo "something went wrong",mysqli_error($db);
                }

            }
    }
    
    
}
    ?>
<div class="card-header text-center">
	<i class="fa fa-user-plus"></i> <?= ((isset($_GET['edit'])?'Edit':'')) ?> Student Detail
</div>
<div class="card-body">
	<form method="post" id="student_register_form" action="updateStudent.php?<?=((isset($_GET['edit']))?'edit='.$edit_id:'');?>">
		<div class="form-group">
			<label>Full Name:</label>
			<input type="text"  value="<?=$student_full_name;?>" name="student_full_name" id="student_full_name" class="form-control">
		</div>
		<div class="form-group">
			<label>Phone Number:</label>
			<input type="number"  value="<?=$student_phone_no;?>" name="student_phone_no" id="student_phone_no" class="form-control" >
		</div>
		<div class="form-group">
			<label>Matric Number:</label>
			<input type="text"  value="<?=$student_matric_no;?>" name="student_matric_no" id="student_matric_no" class="form-control" >
		</div>
		<div class="form-group">
			<label>Department:</label>
			<input type="text"  value="<?=$student_department;?>" name="student_department" id="student_department" class="form-control" >
		</div>
			<div class="form-group">
			<label>Level:</label>
			<input type="text"  value="<?=$student_level;?>" name="student_level" id="student_level" class="form-control" >
		</div>
		<div class="form-group">
			<label>Enter Email Address</label>
		<input type="text"  value="<?=$student_email_address;?>" name="student_email_address" id="student_email_address" class="form-control" >
		</div>
		<div class="form-group">
			<label>Username:</label>
			<input type="text"  value="<?=$student_username;?>" name="student_username" id="student_username" class="form-control">
		</div>
		<div class="form-group">
		<input type="submit"  value="<?=((isset($_GET['edit']))?'Edit ':'');?> Student Detail" name="student_register" id="student_register"  class="btn btn-info">
			<a href="students.php" class="btn btn-danger">Cancel</a>
	</div>
	</form>

</div>
</div>

      </div>

    </div>


