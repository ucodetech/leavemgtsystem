<?php
  require_once '../core/init.php';
		 require_once '../helpers/helpers.php';    
    if (!super_is_logged_in()) {
        super_login_error_redirect();
    }
    if (!has_permission_super('superuser')) {
        super_permission_error_redirect();
    }
    include 'includes/head.php';
    include 'includes/nav.php';

    $sql = $db->query("SELECT * FROM superuser WHERE super_id = '$super_admin_id ' ");
    $data = mysqli_fetch_assoc($sql);
    $proId = $data['super_id'];
    $sqlimg = $db->query("SELECT * FROM superprofile WHERE super_id = '$proId'  ");
    $img = mysqli_fetch_assoc($sqlimg);

?>          
            <div class="content-wrapper">
            <div class="content">
                <div class="container-fluid">
                    <h3 class="text-center"><?=$data['super_full_name'];?> <span class="text-info">Profile</span></h3><hr>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Profile</h4>
                                </div>
                                <div class="card-body">
                <form>
                    <div class="row">

                        <div class="col-md-4 pr-1">
                            <div class="form-group">
                                <label class="text-dark">Permission</label>
                                <input type="text" class="form-control" disabled="" placeholder="Permission" value="<?=$data['permissions'];?>">
                            </div>
                        </div>
                        
                        <div class="col-md-8 pl-1">
                            <div class="form-group">
                                <label for="exampleInputEmail1 text-dark">Email address</label>
                                <input type="email" class="form-control" placeholder="Email" value="<?=$data['super_email'];?>" disabled="">
                            </div>
                        </div>
                   
                        <div class="col-md-6 pr-1">
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$super_data['first'];?>" disabled="">
                            </div>
                        </div>
                        <div class="col-md-6 pl-1">
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" class="form-control" placeholder="" value="<?=$super_data['last'];?>" disabled="">
                            </div>
                        </div>
                    
                    </div>
                    
               
                    <a href="superedit.php?edit=<?=$data['super_id'];?>" class="btn btn-info btn-fill pull-right">Update Profile</a>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
        </div>
        <div class="col-md-4">
        <div class="card card-user">
            <div class="card-image">
                <img src="profile/ba.png" alt="banner" class="img-fluid">
            </div>
            <div class="card-body">
                <div class="author">
                    <a href="#">
                        <?php 
              $sql4 = "SELECT * FROM superuser WHERE super_id = '$super_admin_id' ";
              $query4 = $db->query($sql4);
              if (mysqli_num_rows($query4) > 0) {
                while ($row = mysqli_fetch_assoc($query4)) {
                  $adminid = $row['super_id'];
                  
                  $sqlim = "SELECT * FROM superprofile WHERE super_id = '$adminid' ";
                  $queryim = $db->query($sqlim);
                  if (mysqli_num_rows($queryim) > 0) {
                    while ($rowimg = mysqli_fetch_assoc($queryim)) {
                     
                      
                        if ($rowimg['status'] == 1) {
                          echo "<img src='profile/profile".$adminid.".jpg?'".mt_rand()." class='rounded-circle img-fluid'  alt='profile' width='80'>
              ";
                        }else{
                          ?>
                          <img class="rounded-circle img-fluid" src="profile/default.png" alt="Admin Image" width="80">

                          <?php
                        }
                    }
                  }
                }
               } 
           ?>
                        <h5 class="title"><?=$data['super_full_name'];?></h5>
                    </a>
                    <p class="description">
                        <?=$data['super_email'];?>
                    </p>
                </div>
                
            </div>
            <hr>
            <div class="button-container mr-auto ml-auto">
                <button href="#" class="btn btn-simple btn-link btn-icon">
                    <i class="fa fa-facebook-square"></i>
                </button>
                <button href="#" class="btn btn-simple btn-link btn-icon">
                    <i class="fa fa-twitter"></i>
                </button>
                <button href="#" class="btn btn-simple btn-link btn-icon">
                    <i class="fa fa-google-plus-square"></i>
                </button>
            </div>
        </div>
        </div>
        </div>
        </div>
         <div class="container-fluid">
            <h4 class="text-info text-center">Update Your Profile (<span class="text-danger"><?=$super_data['first'];?></span>)</h4><hr>
                <div class="container">
                  <div class="row">
                    <div class="col-md-6">
                     <?php 
              $sql4 = "SELECT * FROM superuser WHERE super_id = '$super_admin_id' ";
              $query4 = $db->query($sql4);
              if (mysqli_num_rows($query4) > 0) {
                while ($row = mysqli_fetch_assoc($query4)) {
                  $adminid = $row['super_id'];
                  
                  $sqlim = "SELECT * FROM superprofile WHERE super_id = '$adminid' ";
                  $queryim = $db->query($sqlim);
                  if (mysqli_num_rows($queryim) > 0) {
                    while ($rowimg = mysqli_fetch_assoc($queryim)) {
                     
                      
                        if ($rowimg['status'] == 1) {
                          echo "<img src='profile/profile".$adminid.".jpg?'".mt_rand()." class='rounded-circle align-self-start mr-3' style='border-radius: 10% !important;margin: 2px;' alt='...' width='200' height='200'>
               <span class='text-success onl'>.</span>  <span class='onl1'>Active </span> <br>";
                        }else{
                          ?>
                           <img src='profile/default.png' class='rounded-circle align-self-start mr-3' style='border-radius: 10% !important;margin: 2px;' width='200' height='200'>
               <span class="onl1">Update Your Profile to have your Image appear here!   </span> <br>
                          <?php
                        }
                    }
                  }
                }
               } 
           ?>
                
                </div>
                <div class="col-md-4">
                  <p class="alert alert-danger" >
                
                  Only .jpg extsion is allowed. thanks
                
              </p>
                </div>
              </div>
            </div>

              
            <hr>
         <form action="update_pro.php" method="POST" enctype="multipart/form-data"> 
             <div class="col-md-6 form-group">
                    <label for="DOA" class="text-dark">Profile Pic: <span class="text-danger">*</span></label>
                    <input type="file" name="file"  class="form-control">
                  </div>

                  <div class="col-md-12 form-group" align="right">
                    <input type="submit" name="upload" value="Upload"  class="btn btn-success">
                  </div>
         </form>
          </div>
            
        </div>
    </div>
<?php
    include 'includes/footer.php';

?>